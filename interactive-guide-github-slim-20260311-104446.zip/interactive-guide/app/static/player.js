import { bootPlayerRuntime } from "./player/runtime.js";

bootPlayerRuntime();
