function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function placementOrder(preferred, spaces) {
  const bySpace = Object.entries(spaces)
    .sort((a, b) => b[1] - a[1])
    .map(([placement]) => placement);

  if (preferred && preferred !== "auto" && bySpace.includes(preferred)) {
    return [preferred, ...bySpace.filter((placement) => placement !== preferred)];
  }

  return bySpace;
}

function candidatePosition(placement, anchorRect, tooltipRect, offset) {
  const anchorCenterX = anchorRect.left + anchorRect.width / 2;
  const anchorCenterY = anchorRect.top + anchorRect.height / 2;

  if (placement === "top") {
    return {
      left: anchorCenterX - tooltipRect.width / 2,
      top: anchorRect.top - tooltipRect.height - offset,
    };
  }
  if (placement === "bottom") {
    return {
      left: anchorCenterX - tooltipRect.width / 2,
      top: anchorRect.bottom + offset,
    };
  }
  if (placement === "left") {
    return {
      left: anchorRect.left - tooltipRect.width - offset,
      top: anchorCenterY - tooltipRect.height / 2,
    };
  }
  return {
    left: anchorRect.right + offset,
    top: anchorCenterY - tooltipRect.height / 2,
  };
}

function fitsViewport(position, tooltipRect, viewportWidth, viewportHeight, padding) {
  return (
    position.left >= padding &&
    position.top >= padding &&
    position.left + tooltipRect.width <= viewportWidth - padding &&
    position.top + tooltipRect.height <= viewportHeight - padding
  );
}

export function computeTooltipLayout({
  anchorRect,
  tooltipRect,
  preferred = "auto",
  padding = 12,
  offset = 14,
  viewportWidth = window.innerWidth,
  viewportHeight = window.innerHeight,
}) {
  const spaces = {
    top: anchorRect.top - padding,
    bottom: viewportHeight - anchorRect.bottom - padding,
    left: anchorRect.left - padding,
    right: viewportWidth - anchorRect.right - padding,
  };

  const order = placementOrder(preferred, spaces);
  let placement = order[0] || "right";
  let position = candidatePosition(placement, anchorRect, tooltipRect, offset);

  for (const candidate of order) {
    const candidatePos = candidatePosition(candidate, anchorRect, tooltipRect, offset);
    if (fitsViewport(candidatePos, tooltipRect, viewportWidth, viewportHeight, padding)) {
      placement = candidate;
      position = candidatePos;
      break;
    }
  }

  position = {
    left: clamp(position.left, padding, viewportWidth - tooltipRect.width - padding),
    top: clamp(position.top, padding, viewportHeight - tooltipRect.height - padding),
  };

  const centerX = anchorRect.left + anchorRect.width / 2;
  const centerY = anchorRect.top + anchorRect.height / 2;
  let arrowLeft = tooltipRect.width / 2;
  let arrowTop = tooltipRect.height / 2;

  if (placement === "top" || placement === "bottom") {
    arrowLeft = clamp(centerX - position.left, 16, tooltipRect.width - 16);
    arrowTop = placement === "top" ? tooltipRect.height : 0;
  } else {
    arrowTop = clamp(centerY - position.top, 16, tooltipRect.height - 16);
    arrowLeft = placement === "left" ? tooltipRect.width : 0;
  }

  return {
    placement,
    left: position.left,
    top: position.top,
    arrowLeft,
    arrowTop,
  };
}
