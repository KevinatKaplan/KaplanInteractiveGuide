const EVENT_PREFIX = "supaclone";
const SESSION_COOKIE = "supaclone_session_id";
const SESSION_MAX_AGE_SECONDS = 60 * 60 * 24 * 30;

function readCookie(name) {
  const encoded = `${name}=`;
  const parts = document.cookie.split(";").map((part) => part.trim());
  for (const part of parts) {
    if (part.startsWith(encoded)) {
      return decodeURIComponent(part.slice(encoded.length));
    }
  }
  return null;
}

function writeCookie(name, value) {
  document.cookie = `${name}=${encodeURIComponent(value)}; Path=/; Max-Age=${SESSION_MAX_AGE_SECONDS}; SameSite=Lax`;
}

function createSessionId() {
  if (window.crypto?.randomUUID) {
    return window.crypto.randomUUID();
  }
  return `sess_${Date.now()}_${Math.random().toString(16).slice(2, 10)}`;
}

export function getSessionId() {
  let sessionId = readCookie(SESSION_COOKIE);
  if (!sessionId) {
    sessionId = window.localStorage.getItem(SESSION_COOKIE);
  }
  if (!sessionId) {
    sessionId = createSessionId();
  }
  writeCookie(SESSION_COOKIE, sessionId);
  try {
    window.localStorage.setItem(SESSION_COOKIE, sessionId);
  } catch (_error) {
    // Ignore localStorage write failures.
  }
  return sessionId;
}

function isDevMode() {
  const host = window.location.hostname;
  return host === "localhost" || host === "127.0.0.1";
}

function shouldTrackOnServer(payload) {
  return Boolean(payload?.demoId && payload?.slug);
}

async function postAnalytics(fullEventName, payload) {
  if (!shouldTrackOnServer(payload)) {
    return;
  }

  const body = JSON.stringify({
    eventName: fullEventName,
    demoId: payload.demoId,
    slug: payload.slug,
    sessionId: payload.sessionId,
    stepId: payload.stepId || null,
    index: Number.isInteger(payload.index) ? payload.index : null,
    hotspotId: payload.hotspotId || null,
    feedbackScore: Number.isInteger(payload.feedbackScore) ? payload.feedbackScore : null,
    feedbackText: payload.feedbackText || null,
    ts: payload.ts,
  });

  try {
    const response = await fetch("/api/analytics/events", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body,
      keepalive: true,
    });

    if (!response.ok && isDevMode()) {
      // eslint-disable-next-line no-console
      console.warn(`[${EVENT_PREFIX}] analytics post failed`, fullEventName, response.status);
    }
  } catch (_error) {
    if (isDevMode()) {
      // eslint-disable-next-line no-console
      console.warn(`[${EVENT_PREFIX}] analytics post failed`, fullEventName);
    }
  }
}

export function emitPlayerEvent(eventName, detail = {}) {
  const payload = {
    ...detail,
    ts: detail.ts || new Date().toISOString(),
    sessionId: detail.sessionId || getSessionId(),
  };
  const fullName = `${EVENT_PREFIX}:${eventName}`;
  window.dispatchEvent(new CustomEvent(fullName, { detail: payload }));
  if (window.parent && window.parent !== window) {
    window.parent.postMessage(
      {
        source: "supaclone-player",
        eventName: fullName,
        detail: payload,
      },
      "*"
    );
  }
  if (isDevMode()) {
    // eslint-disable-next-line no-console
    console.info(`[${EVENT_PREFIX}] ${eventName}`, payload);
  }
  postAnalytics(fullName, payload);
  return payload;
}
