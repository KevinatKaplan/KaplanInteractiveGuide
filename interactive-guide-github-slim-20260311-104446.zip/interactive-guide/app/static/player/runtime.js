import { emitPlayerEvent, getSessionId } from "./events.js";
import { computeTooltipLayout } from "./tooltip.js";

const DEFAULT_WIDTH = 1280;
const DEFAULT_HEIGHT = 720;
const FRAME_PADDING = 20;

const elements = {
  root: document.getElementById("player-root"),
  introScreen: document.getElementById("intro-screen"),
  introTitle: document.getElementById("intro-title"),
  introBody: document.getElementById("intro-body"),
  introChapters: document.getElementById("intro-chapters"),
  introSteps: document.getElementById("intro-steps"),
  introStart: document.getElementById("intro-start"),
  introSkip: document.getElementById("intro-skip"),
  introPreviewImage: document.getElementById("intro-preview-image"),
  introPreviewVideo: document.getElementById("intro-preview-video"),
  introPreviewPlaceholder: document.getElementById("intro-preview-placeholder"),
  chapterSidebar: document.getElementById("chapter-sidebar"),
  chapterNav: document.getElementById("chapter-nav"),
  toggleChapters: document.getElementById("toggle-chapters"),
  frameLayout: document.getElementById("frame-layout"),
  frameCenter: document.querySelector(".frame-center"),
  frameViewport: document.getElementById("frame-viewport"),
  frameHolder: document.getElementById("frame-holder"),
  frameContent: document.getElementById("frame-content"),
  overlayLayer: document.getElementById("overlay-layer"),
  loading: document.getElementById("player-loading"),
  image: document.getElementById("player-image"),
  video: document.getElementById("player-video"),
  iframe: document.getElementById("player-iframe"),
  hotspot: document.getElementById("player-hotspot"),
  endScreen: document.getElementById("end-screen"),
  progress: document.getElementById("progress"),
  restart: document.getElementById("restart"),
  restartEnd: document.getElementById("restart-end"),
  prev: document.getElementById("prev-step"),
  next: document.getElementById("next-step"),
  openTab: document.getElementById("open-new-tab"),
  fullscreen: document.getElementById("fullscreen-toggle"),
  badge: document.getElementById("badge-slot"),
  feedbackModal: document.getElementById("feedback-modal"),
  feedbackRating: document.getElementById("feedback-rating"),
  feedbackText: document.getElementById("feedback-text"),
  feedbackStatus: document.getElementById("feedback-status"),
  feedbackSkip: document.getElementById("feedback-skip"),
  feedbackSubmit: document.getElementById("feedback-submit"),
  tooltipPortal: document.getElementById("tooltip-portal"),
  arrow: document.getElementById("player-arrow"),
  tooltip: document.getElementById("player-tooltip"),
  tooltipArrow: document.getElementById("tooltip-arrow"),
  tooltipTitle: document.getElementById("tooltip-title"),
  tooltipBody: document.getElementById("tooltip-body"),
  tooltipHint: document.getElementById("tooltip-hint"),
  tooltipPrev: document.getElementById("tooltip-prev"),
  tooltipNext: document.getElementById("tooltip-next"),
};

const state = {
  slug: document.body.dataset.slug,
  demo: null,
  steps: [],
  stepById: new Map(),
  screenById: new Map(),
  chapters: [],
  currentStepId: null,
  history: [],
  visitedStepIds: new Set(),
  runStarted: false,
  runCompleted: false,
  feedbackSubmitted: false,
  feedbackSkipped: false,
  selectedFeedbackScore: null,
  chapterGroups: [],
  chapterExpanded: {},
  chaptersVisible: true,
  introVisible: false,
  tooltipHidden: false,
  renderToken: 0,
  hotspotRect: null,
  frame: {
    naturalWidth: DEFAULT_WIDTH,
    naturalHeight: DEFAULT_HEIGHT,
    width: DEFAULT_WIDTH,
    height: DEFAULT_HEIGHT,
    scale: 1,
  },
};
let frameResizeObserver = null;

function validatePlayerDom() {
  const requiredKeys = [
    "root",
    "introScreen",
    "introTitle",
    "introBody",
    "introChapters",
    "introSteps",
    "introStart",
    "introSkip",
    "introPreviewImage",
    "introPreviewVideo",
    "introPreviewPlaceholder",
    "frameViewport",
    "frameLayout",
    "frameCenter",
    "frameHolder",
    "frameContent",
    "loading",
    "image",
    "video",
    "iframe",
    "hotspot",
    "endScreen",
    "progress",
    "restart",
    "restartEnd",
    "prev",
    "next",
    "openTab",
    "fullscreen",
    "feedbackModal",
    "feedbackRating",
    "feedbackText",
    "feedbackStatus",
    "feedbackSkip",
    "feedbackSubmit",
    "tooltip",
    "tooltipArrow",
    "arrow",
    "tooltipTitle",
    "tooltipBody",
    "tooltipHint",
    "tooltipPrev",
    "tooltipNext",
  ];

  const missing = requiredKeys.filter((key) => !elements[key]);
  if (!missing.length) {
    return true;
  }

  // eslint-disable-next-line no-console
  console.error("Player DOM is missing required elements:", missing);
  return false;
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function sortByOrder(items) {
  return [...(items || [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function renderSafeMarkdown(value) {
  let html = escapeHtml(value || "");

  html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_full, label, href) => {
    const safeLabel = escapeHtml(label);
    const safeHref = escapeHtml(href);
    return `<a href="${safeHref}" target="_blank" rel="noopener noreferrer">${safeLabel}</a>`;
  });

  html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/\*([^*]+)\*/g, "<em>$1</em>");
  html = html.replace(/`([^`]+)`/g, "<code>$1</code>");

  return html.replace(/\n/g, "<br>");
}

function chapterCount() {
  if (state.chapters.length) {
    return state.chapters.filter((chapter) => state.steps.some((step) => step.chapterId === chapter.id)).length;
  }
  return state.steps.length ? 1 : 0;
}

function getIntroConfig() {
  const intro = state.demo?.ui?.intro || {};
  return {
    enabled: intro.enabled !== false,
    title: intro.title || state.demo?.title || "Interactive Demo",
    body:
      intro.body ||
      `Learn this workflow in ${state.steps.length} guided step${state.steps.length === 1 ? "" : "s"}.`,
    startLabel: intro.startLabel || "Start Interactive Demo",
    skipLabel: intro.skipLabel || "Skip Intro",
  };
}

function buildMaps(demo) {
  state.steps = sortByOrder(demo.steps);
  state.stepById = new Map(state.steps.map((step) => [step.id, step]));
  state.screenById = new Map((demo.screens || []).map((screen) => [screen.id, screen]));
  state.chapters = sortByOrder(demo.chapters);
  state.chapterGroups = [];
  state.chapterExpanded = {};
}

function getStartStepId() {
  return state.demo.startStepId || state.steps[0]?.id || null;
}

function getStepIndex(stepId) {
  return state.steps.findIndex((step) => step.id === stepId);
}

function getCurrentStep() {
  return state.stepById.get(state.currentStepId) || null;
}

function getCurrentScreen() {
  const step = getCurrentStep();
  if (!step?.screenId) {
    return null;
  }
  return state.screenById.get(step.screenId) || null;
}

function normalizeScreenDimensions(screen) {
  const width = Number(screen?.naturalWidth) || DEFAULT_WIDTH;
  const height = Number(screen?.naturalHeight) || DEFAULT_HEIGHT;
  return {
    width: Math.max(Math.round(width), 1),
    height: Math.max(Math.round(height), 1),
  };
}

function showLoading(isVisible) {
  elements.loading.classList.toggle("hidden", !isVisible);
}

function hideAllMedia() {
  elements.image.classList.add("hidden");
  elements.video.classList.add("hidden");
  elements.iframe.classList.add("hidden");
}

function setFrameSize(screen) {
  const frameRect = (elements.frameCenter || elements.frameViewport).getBoundingClientRect();
  const availableWidth = Math.max(frameRect.width - FRAME_PADDING * 2, 280);
  const availableHeight = Math.max(frameRect.height - FRAME_PADDING * 2, 220);

  const natural = normalizeScreenDimensions(screen);
  const scale = Math.min(availableWidth / natural.width, availableHeight / natural.height, 1);
  const width = Math.max(Math.round(natural.width * scale), 1);
  const height = Math.max(Math.round(natural.height * scale), 1);

  state.frame = {
    naturalWidth: natural.width,
    naturalHeight: natural.height,
    width,
    height,
    scale,
  };

  elements.frameHolder.style.width = `${width}px`;
  elements.frameHolder.style.height = `${height}px`;
}

function renderBadge() {
  const badge = state.demo?.ui?.badge;
  if (!badge || !badge.enabled) {
    elements.badge.classList.add("hidden");
    elements.badge.removeAttribute("href");
    elements.badge.textContent = "";
    return;
  }

  const icon = badge.icon ? `${badge.icon} ` : "";
  elements.badge.textContent = `${icon}${badge.label || "Guided demo"}`;
  if (badge.href) {
    elements.badge.href = badge.href;
  } else {
    elements.badge.removeAttribute("href");
  }
  elements.badge.classList.remove("hidden");
}

function computeChapterGroups() {
  const groups = [];
  if (state.chapters.length) {
    for (const chapter of state.chapters) {
      const chapterSteps = state.steps.filter((step) => step.chapterId === chapter.id);
      if (!chapterSteps.length) {
        continue;
      }
      groups.push({
        id: chapter.id,
        title: chapter.title,
        steps: chapterSteps,
      });
    }
    const ungrouped = state.steps.filter((step) => !step.chapterId);
    if (ungrouped.length) {
      groups.push({
        id: "ungrouped-steps",
        title: "Ungrouped",
        steps: ungrouped,
      });
    }
  } else if (state.steps.length) {
    groups.push({
      id: "all-steps",
      title: "All steps",
      steps: state.steps,
    });
  }
  return groups;
}

function setChapterToggleState(hasChapters) {
  if (!elements.toggleChapters) {
    return;
  }
  elements.toggleChapters.classList.toggle("hidden", !hasChapters);
  if (!hasChapters) {
    elements.toggleChapters.textContent = "Hide Outline";
    return;
  }
  elements.toggleChapters.textContent = state.chaptersVisible ? "Hide Outline" : "Show Outline";
}

function renderChapterNav() {
  if (!elements.chapterNav || !elements.chapterSidebar) {
    return;
  }

  elements.chapterNav.innerHTML = "";
  state.chapterGroups = computeChapterGroups();
  const fragment = document.createDocumentFragment();

  for (const group of state.chapterGroups) {
    const completed = group.steps.filter((step) => state.visitedStepIds.has(step.id)).length;
    const total = group.steps.length;
    const isActive = group.steps.some((step) => step.id === state.currentStepId);
    if (!(group.id in state.chapterExpanded)) {
      state.chapterExpanded[group.id] = isActive;
    }
    if (isActive) {
      state.chapterExpanded[group.id] = true;
    }

    const section = document.createElement("section");
    section.className = "chapter-section";
    if (isActive) {
      section.classList.add("active");
    }
    section.dataset.chapterId = group.id;

    const header = document.createElement("button");
    header.type = "button";
    header.className = "chapter-section-head";
    header.setAttribute("aria-expanded", state.chapterExpanded[group.id] ? "true" : "false");

    const titleWrap = document.createElement("div");
    titleWrap.className = "chapter-section-title-wrap";

    const title = document.createElement("div");
    title.className = "chapter-section-title";
    title.textContent = group.title;

    const lessons = document.createElement("div");
    lessons.className = "chapter-section-lessons";
    lessons.textContent = `${total} lesson${total === 1 ? "" : "s"}`;

    titleWrap.appendChild(title);
    titleWrap.appendChild(lessons);

    const status = document.createElement("div");
    status.className = "chapter-section-status";
    status.textContent = `${completed}/${total}`;

    const chevron = document.createElement("span");
    chevron.className = `chapter-section-chevron${state.chapterExpanded[group.id] ? " expanded" : ""}`;
    chevron.textContent = "⌄";

    header.appendChild(titleWrap);
    header.appendChild(status);
    header.appendChild(chevron);

    const list = document.createElement("div");
    list.className = "chapter-step-list";
    if (!state.chapterExpanded[group.id]) {
      list.classList.add("hidden");
    }

    group.steps.forEach((step) => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "chapter-step-link";
      if (step.id === state.currentStepId) {
        row.classList.add("active");
      }
      if (state.visitedStepIds.has(step.id)) {
        row.classList.add("visited");
      }

      const dot = document.createElement("span");
      dot.className = "chapter-step-dot";
      dot.textContent = "•";

      const label = document.createElement("span");
      label.textContent = step.title || "Untitled step";

      row.appendChild(dot);
      row.appendChild(label);
      row.addEventListener("click", () => {
        setStep(step.id, { pushHistory: true });
      });
      list.appendChild(row);
    });

    header.addEventListener("click", () => {
      state.chapterExpanded[group.id] = !state.chapterExpanded[group.id];
      renderChapterNav();
    });

    section.appendChild(header);
    section.appendChild(list);
    fragment.appendChild(section);
  }

  elements.chapterNav.appendChild(fragment);
  const hasChapters = Boolean(state.chapterGroups.length);
  elements.chapterNav.classList.toggle("hidden", !hasChapters);
  elements.chapterSidebar.classList.toggle("hidden", !hasChapters || !state.chaptersVisible);
  elements.frameLayout.classList.toggle("has-chapters", hasChapters && state.chaptersVisible);
  setChapterToggleState(hasChapters);
}

function updateActiveChapter() {
  renderChapterNav();
}

function updateProgress() {
  if (!state.steps.length) {
    elements.progress.textContent = "0 / 0";
    return;
  }
  const index = getStepIndex(state.currentStepId);
  if (index < 0) {
    elements.progress.textContent = `${state.steps.length} / ${state.steps.length}`;
    return;
  }
  elements.progress.textContent = `${index + 1} / ${state.steps.length}`;
}

function updateControlState() {
  if (state.introVisible) {
    elements.prev.disabled = true;
    elements.next.disabled = true;
    elements.tooltipPrev.disabled = true;
    elements.tooltipNext.disabled = true;
    return;
  }
  const index = getStepIndex(state.currentStepId);
  const noStep = index < 0;
  const currentStep = getCurrentStep();
  const hasNext = Boolean(getNextStepId(currentStep));
  elements.prev.disabled = noStep || state.history.length === 0;
  elements.next.disabled = noStep || !hasNext;
  elements.tooltipPrev.disabled = elements.prev.disabled;
  elements.tooltipNext.disabled = elements.next.disabled;
}

function setFeedbackStatus(message = "") {
  if (!elements.feedbackStatus) {
    return;
  }
  elements.feedbackStatus.textContent = message;
}

function setFeedbackScore(score) {
  state.selectedFeedbackScore = score;
  elements.feedbackSubmit.disabled = !Number.isInteger(score);
  const buttons = elements.feedbackRating.querySelectorAll(".feedback-score-btn");
  buttons.forEach((button) => {
    const value = Number(button.dataset.score || 0);
    button.classList.toggle("selected", value === score);
    button.setAttribute("aria-checked", value === score ? "true" : "false");
  });
}

function closeFeedbackModal() {
  elements.feedbackModal.classList.add("hidden");
}

function openFeedbackModal() {
  if (!elements.feedbackModal || state.feedbackSubmitted || state.feedbackSkipped) {
    return;
  }
  elements.feedbackModal.classList.remove("hidden");
  elements.feedbackText.value = "";
  setFeedbackScore(null);
  setFeedbackStatus("");
}

function submitFeedback() {
  if (!Number.isInteger(state.selectedFeedbackScore)) {
    setFeedbackStatus("Please choose a rating.");
    return;
  }
  elements.feedbackSubmit.disabled = true;
  setFeedbackStatus("Submitting...");
  emitPlayerEvent("feedback_submit", {
    demoId: state.demo.id,
    slug: state.demo.slug,
    feedbackScore: state.selectedFeedbackScore,
    feedbackText: (elements.feedbackText.value || "").trim(),
  });
  state.feedbackSubmitted = true;
  setFeedbackStatus("Thanks for your feedback.");
  window.setTimeout(() => {
    closeFeedbackModal();
    setFeedbackStatus("");
  }, 700);
}

function tooltipAnchorRect(hotspotRect) {
  if (hotspotRect) {
    return hotspotRect;
  }

  const frameRect = elements.frameHolder.getBoundingClientRect();
  return {
    left: frameRect.left + frameRect.width / 2,
    right: frameRect.left + frameRect.width / 2,
    top: frameRect.top + frameRect.height / 2,
    bottom: frameRect.top + frameRect.height / 2,
    width: 1,
    height: 1,
  };
}

function setTooltipPlacement(anchorRect, preferred) {
  const tooltipRect = elements.tooltip.getBoundingClientRect();
  const layout = computeTooltipLayout({
    anchorRect,
    tooltipRect,
    preferred: preferred || "auto",
  });

  elements.tooltip.style.left = `${layout.left}px`;
  elements.tooltip.style.top = `${layout.top}px`;
  elements.tooltip.dataset.placement = layout.placement;

  elements.tooltipArrow.style.left = `${layout.arrowLeft}px`;
  elements.tooltipArrow.style.top = `${layout.arrowTop}px`;
}

function showTooltip(step, hotspotRect) {
  if (!step || state.tooltipHidden) {
    elements.tooltip.classList.add("hidden");
    return;
  }

  elements.tooltipTitle.textContent = step.title || "Step";
  elements.tooltipBody.innerHTML = renderSafeMarkdown(step.body || "");
  elements.tooltipBody.classList.toggle("tooltip-clickable", Boolean(step.advanceOnTooltipClick));
  elements.tooltipHint.classList.remove("visible");

  const hasNext = Boolean(getNextStepId(step));
  elements.next.disabled = !hasNext;
  elements.tooltipNext.disabled = !hasNext;

  elements.tooltip.classList.remove("hidden");
  setTooltipPlacement(tooltipAnchorRect(hotspotRect), step.tooltipPosition || "auto");
}

function hideTooltip() {
  state.tooltipHidden = true;
  elements.tooltip.classList.add("hidden");
  elements.arrow.classList.add("hidden");
}

function hideIntroPreviewMedia() {
  elements.introPreviewImage.classList.add("hidden");
  elements.introPreviewVideo.classList.add("hidden");
  elements.introPreviewPlaceholder.classList.add("hidden");
  elements.introPreviewVideo.pause();
  elements.introPreviewVideo.removeAttribute("src");
  elements.introPreviewVideo.load();
}

function renderIntroPreview() {
  hideIntroPreviewMedia();
  const startStep = state.stepById.get(getStartStepId());
  const previewScreen = startStep?.screenId ? state.screenById.get(startStep.screenId) : null;
  if (!previewScreen) {
    elements.introPreviewPlaceholder.classList.remove("hidden");
    return;
  }

  const mediaType = previewScreen.mediaType || "image";
  const mediaUrl = buildAbsoluteMediaUrl(previewScreen.mediaUrl || previewScreen.imageUrl);

  if (mediaType === "video") {
    elements.introPreviewVideo.src = mediaUrl;
    elements.introPreviewVideo.classList.remove("hidden");
    elements.introPreviewVideo.play().catch(() => {
      elements.introPreviewVideo.pause();
    });
    return;
  }

  if (mediaType === "html") {
    elements.introPreviewPlaceholder.textContent = "HTML walkthrough preview";
    elements.introPreviewPlaceholder.classList.remove("hidden");
    return;
  }

  elements.introPreviewImage.src = mediaUrl;
  elements.introPreviewImage.classList.remove("hidden");
}

function showIntroScreen() {
  const intro = getIntroConfig();
  if (!intro.enabled) {
    startDemoFromIntro();
    return;
  }
  state.introVisible = true;
  elements.root.classList.add("intro-active");
  elements.introScreen.classList.remove("hidden");
  elements.endScreen.classList.add("hidden");
  elements.hotspot.classList.add("hidden");
  elements.arrow.classList.add("hidden");
  elements.tooltip.classList.add("hidden");
  elements.loading.classList.add("hidden");
  elements.progress.textContent = `0 / ${state.steps.length}`;
  elements.introTitle.textContent = intro.title;
  elements.introBody.textContent = intro.body;
  elements.introStart.textContent = intro.startLabel;
  elements.introSkip.textContent = intro.skipLabel;
  const totalChapters = chapterCount();
  elements.introChapters.textContent = `${totalChapters} chapter${totalChapters === 1 ? "" : "s"}`;
  elements.introSteps.textContent = `${state.steps.length} step${state.steps.length === 1 ? "" : "s"}`;
  renderChapterNav();
  renderIntroPreview();
  updateControlState();
}

function hideIntroScreen() {
  state.introVisible = false;
  elements.root.classList.remove("intro-active");
  elements.introScreen.classList.add("hidden");
  elements.introPreviewVideo.pause();
}

function nudgeTooltipHint() {
  elements.tooltip.classList.remove("shake");
  void elements.tooltip.offsetWidth;
  elements.tooltip.classList.add("shake");
  elements.tooltipHint.classList.add("visible");
  window.setTimeout(() => elements.tooltipHint.classList.remove("visible"), 1200);
}

function getHotspotCenterViewport(hotspotRect) {
  if (!hotspotRect) {
    return null;
  }
  const frameRect = elements.frameHolder.getBoundingClientRect();
  return {
    x: frameRect.left + hotspotRect.x + hotspotRect.width / 2,
    y: frameRect.top + hotspotRect.y + hotspotRect.height / 2,
  };
}

function getArrowStartPoint(target, placement, tooltipRect) {
  if (placement === "left") {
    return { x: tooltipRect.right, y: clamp(target.y, tooltipRect.top + 14, tooltipRect.bottom - 14) };
  }
  if (placement === "right") {
    return { x: tooltipRect.left, y: clamp(target.y, tooltipRect.top + 14, tooltipRect.bottom - 14) };
  }
  if (placement === "top") {
    return { x: clamp(target.x, tooltipRect.left + 14, tooltipRect.right - 14), y: tooltipRect.bottom };
  }
  return { x: clamp(target.x, tooltipRect.left + 14, tooltipRect.right - 14), y: tooltipRect.top };
}

function updateArrowHint(step, hotspotRect) {
  if (!step || !hotspotRect || (step.hintType || "click") !== "arrow" || elements.tooltip.classList.contains("hidden")) {
    elements.arrow.classList.add("hidden");
    return;
  }

  const target = getHotspotCenterViewport(hotspotRect);
  if (!target) {
    elements.arrow.classList.add("hidden");
    return;
  }

  const tooltipRect = elements.tooltip.getBoundingClientRect();
  const placement = elements.tooltip.dataset.placement || "right";
  const start = getArrowStartPoint(target, placement, tooltipRect);
  const dx = target.x - start.x;
  const dy = target.y - start.y;
  const length = Math.max(Math.hypot(dx, dy), 28);
  const angle = Math.atan2(dy, dx);

  elements.arrow.style.width = `${length}px`;
  elements.arrow.style.left = `${start.x}px`;
  elements.arrow.style.top = `${start.y}px`;
  elements.arrow.style.transform = `translateY(-50%) rotate(${angle}rad)`;
  elements.arrow.classList.remove("hidden");
}

function renderHotspot(step) {
  if (!step?.hotspot) {
    state.hotspotRect = null;
    elements.hotspot.classList.add("hidden");
    return null;
  }

  const { width, height } = state.frame;
  const x = step.hotspot.xPct * width;
  const y = step.hotspot.yPct * height;
  const hotspotWidth = step.hotspot.wPct * width;
  const hotspotHeight = step.hotspot.hPct * height;

  elements.hotspot.className = "player-hotspot";
  const hintType = step.hintType || "click";
  const hotspotType = step.hotspotType || "click";

  if (hotspotType === "highlight") {
    elements.hotspot.classList.add("variant-rect");
  } else if (hotspotType === "none") {
    elements.hotspot.classList.add("variant-none");
  } else {
    elements.hotspot.classList.add("variant-dot");
  }

  if (hintType === "none") {
    elements.hotspot.classList.add("hint-none");
  }
  if (hintType === "arrow") {
    elements.hotspot.classList.add("emphasis-zoom");
  }

  const hotspotId = step.hotspotId || `${step.id}-hotspot`;
  elements.hotspot.dataset.hotspotId = hotspotId;
  elements.hotspot.style.width = `${hotspotWidth}px`;
  elements.hotspot.style.height = `${hotspotHeight}px`;
  elements.hotspot.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  elements.hotspot.setAttribute("aria-label", step.title ? `Go to next step from ${step.title}` : "Go to next step");
  elements.hotspot.classList.remove("hidden");
  state.hotspotRect = {
    x,
    y,
    width: hotspotWidth,
    height: hotspotHeight,
  };
  return state.hotspotRect;
}

function isPointInsideHotspot(point, hotspotRect) {
  if (!hotspotRect) {
    return false;
  }
  return (
    point.x >= hotspotRect.x &&
    point.y >= hotspotRect.y &&
    point.x <= hotspotRect.x + hotspotRect.width &&
    point.y <= hotspotRect.y + hotspotRect.height
  );
}

function getNextStepId(step) {
  if (!step) {
    return null;
  }
  return step.nextStepId || state.steps[getStepIndex(step.id) + 1]?.id || null;
}

function showEndScreen() {
  hideIntroScreen();
  elements.endScreen.classList.remove("hidden");
  hideTooltip();
  elements.hotspot.classList.add("hidden");
  elements.arrow.classList.add("hidden");
  state.hotspotRect = null;
  updateProgress();
  updateControlState();
  elements.video.pause();
  renderChapterNav();

  if (!state.runCompleted) {
    state.runCompleted = true;
    emitPlayerEvent("demo_complete", {
      demoId: state.demo.id,
      slug: state.demo.slug,
    });
    openFeedbackModal();
  }
}

function advanceTo(stepId) {
  if (!stepId) {
    showEndScreen();
    return;
  }
  setStep(stepId, { pushHistory: true });
}

function goNext() {
  const step = getCurrentStep();
  emitStepComplete(step);
  const nextStepId = getNextStepId(step);
  advanceTo(nextStepId);
}

function goPrev() {
  const previous = state.history.pop();
  if (!previous) {
    return;
  }
  setStep(previous, { pushHistory: false });
}

function emitStepView(stepId) {
  const index = getStepIndex(stepId);
  emitPlayerEvent("step_view", {
    demoId: state.demo.id,
    slug: state.demo.slug,
    stepId,
    index,
  });
}

function emitHotspotClick(step, hotspotId) {
  emitPlayerEvent("hotspot_click", {
    demoId: state.demo.id,
    slug: state.demo.slug,
    stepId: step.id,
    hotspotId,
  });
}

function emitStepComplete(step) {
  if (!step) {
    return;
  }
  emitPlayerEvent("step_complete", {
    demoId: state.demo.id,
    slug: state.demo.slug,
    stepId: step.id,
    index: getStepIndex(step.id),
  });
}

function onHotspotActivate() {
  const step = getCurrentStep();
  if (!step?.hotspot) {
    return;
  }
  const hotspotId = elements.hotspot.dataset.hotspotId || `${step.id}-hotspot`;
  emitHotspotClick(step, hotspotId);
  goNext();
}

function buildAbsoluteMediaUrl(url) {
  if (!url) {
    return "";
  }
  if (url.startsWith("http://") || url.startsWith("https://")) {
    return url;
  }
  if (url.startsWith("/")) {
    return `${window.location.origin}${url}`;
  }
  return url;
}

function loadImage(screen) {
  return new Promise((resolve, reject) => {
    hideAllMedia();
    elements.image.classList.remove("hidden");
    elements.image.style.objectFit = screen?.fitMode === "cover" ? "cover" : "contain";

    const syncImageDimensions = () => {
      // Always trust runtime media dimensions for hotspot alignment.
      screen.naturalWidth = elements.image.naturalWidth || DEFAULT_WIDTH;
      screen.naturalHeight = elements.image.naturalHeight || DEFAULT_HEIGHT;
    };

    elements.image.onload = () => {
      syncImageDimensions();
      resolve();
    };
    elements.image.onerror = () => reject(new Error("Image failed to load"));
    const source = buildAbsoluteMediaUrl(screen.mediaUrl || screen.imageUrl);
    if (elements.image.src === source && elements.image.complete) {
      syncImageDimensions();
      resolve();
      return;
    }
    elements.image.src = source;
  });
}

function seekVideo(step) {
  return new Promise((resolve) => {
    const seekTime = Number(step?.timeSec ?? 0);
    if (!Number.isFinite(seekTime) || seekTime <= 0 || !Number.isFinite(elements.video.duration)) {
      resolve();
      return;
    }

    const target = clamp(seekTime, 0, Math.max(elements.video.duration - 0.1, 0));
    const onSeeked = () => {
      elements.video.removeEventListener("seeked", onSeeked);
      resolve();
    };
    elements.video.addEventListener("seeked", onSeeked);
    elements.video.currentTime = target;
    window.setTimeout(() => {
      elements.video.removeEventListener("seeked", onSeeked);
      resolve();
    }, 400);
  });
}

async function loadVideo(screen, step) {
  hideAllMedia();
  elements.video.classList.remove("hidden");
  elements.video.style.objectFit = screen?.fitMode === "cover" ? "cover" : "contain";
  const source = buildAbsoluteMediaUrl(screen.mediaUrl);

  if (elements.video.src !== source) {
    elements.video.src = source;
  }

  await new Promise((resolve, reject) => {
    let timeoutId = null;
    const onLoaded = () => {
      elements.video.removeEventListener("loadedmetadata", onLoaded);
      elements.video.removeEventListener("error", onError);
      if (timeoutId) {
        window.clearTimeout(timeoutId);
      }
      // Always trust runtime media dimensions for hotspot alignment.
      screen.naturalWidth = elements.video.videoWidth || DEFAULT_WIDTH;
      screen.naturalHeight = elements.video.videoHeight || DEFAULT_HEIGHT;
      resolve();
    };
    const onError = () => {
      elements.video.removeEventListener("loadedmetadata", onLoaded);
      elements.video.removeEventListener("error", onError);
      if (timeoutId) {
        window.clearTimeout(timeoutId);
      }
      reject(new Error("Video failed to load"));
    };
    elements.video.addEventListener("loadedmetadata", onLoaded, { once: true });
    elements.video.addEventListener("error", onError, { once: true });
    timeoutId = window.setTimeout(() => {
      onError();
    }, 8000);
    if (elements.video.readyState >= 1) {
      onLoaded();
    }
  });

  await seekVideo(step);

  if (step?.autoPlay) {
    elements.video.play().catch(() => {
      elements.video.pause();
    });
  } else {
    elements.video.pause();
  }
}

async function loadIframe(screen) {
  hideAllMedia();
  elements.iframe.classList.remove("hidden");

  const natural = normalizeScreenDimensions(screen);
  elements.iframe.style.width = `${natural.width}px`;
  elements.iframe.style.height = `${natural.height}px`;
  elements.iframe.style.transform = `scale(${state.frame.scale})`;
  elements.iframe.style.transformOrigin = "left top";
  elements.iframe.style.pointerEvents = screen.interactionMode === "sandbox" ? "auto" : "none";

  await new Promise((resolve, reject) => {
    const onLoad = () => {
      elements.iframe.removeEventListener("load", onLoad);
      resolve();
    };
    elements.iframe.addEventListener("load", onLoad, { once: true });
    elements.iframe.onerror = () => reject(new Error("HTML preview failed to load"));
    elements.iframe.src = buildAbsoluteMediaUrl(screen.mediaUrl);
  });
}

function setTooltipForStep(step, hotspotRect) {
  state.tooltipHidden = false;
  showTooltip(step, hotspotRect ? {
    left: hotspotRect.x + elements.frameHolder.getBoundingClientRect().left,
    right: hotspotRect.x + hotspotRect.width + elements.frameHolder.getBoundingClientRect().left,
    top: hotspotRect.y + elements.frameHolder.getBoundingClientRect().top,
    bottom: hotspotRect.y + hotspotRect.height + elements.frameHolder.getBoundingClientRect().top,
    width: hotspotRect.width,
    height: hotspotRect.height,
  } : null);
}

async function renderCurrentStep() {
  const step = getCurrentStep();
  const token = ++state.renderToken;

  if (!step) {
    showEndScreen();
    return;
  }

  const screen = state.screenById.get(step.screenId);
  if (!screen) {
    showLoading(false);
    elements.tooltipTitle.textContent = "Missing screen";
    elements.tooltipBody.textContent = "This step is not linked to a screen.";
    elements.tooltip.classList.remove("hidden");
    elements.hotspot.classList.add("hidden");
    elements.arrow.classList.add("hidden");
    return;
  }

  showLoading(true);
  elements.endScreen.classList.add("hidden");
  elements.tooltip.classList.add("hidden");

  setFrameSize(screen);

  try {
    const mediaType = screen.mediaType || "image";
    if (mediaType === "video") {
      await loadVideo(screen, step);
    } else if (mediaType === "html") {
      await loadIframe(screen);
    } else {
      await loadImage(screen);
    }
  } catch (_error) {
    // Keep going and show fallback states below.
  }

  if (token !== state.renderToken) {
    return;
  }

  // Recompute frame in case natural dimensions were discovered during media load.
  setFrameSize(screen);

  if (!state.runStarted) {
    state.runStarted = true;
    emitPlayerEvent("demo_start", {
      demoId: state.demo.id,
      slug: state.demo.slug,
    });
  }

  const hotspotRect = renderHotspot(step);
  setTooltipForStep(step, hotspotRect);
  updateArrowHint(step, hotspotRect);

  emitStepView(step.id);
  state.visitedStepIds.add(step.id);
  updateProgress();
  updateControlState();
  updateActiveChapter();
  showLoading(false);
}

function setStep(stepId, options = {}) {
  const { pushHistory = true } = options;
  if (pushHistory && state.currentStepId) {
    state.history.push(state.currentStepId);
  }
  state.currentStepId = stepId;
  renderCurrentStep();
}

function restartRun() {
  state.history = [];
  state.visitedStepIds = new Set();
  state.runStarted = false;
  state.runCompleted = false;
  state.feedbackSubmitted = false;
  state.feedbackSkipped = false;
  state.selectedFeedbackScore = null;
  closeFeedbackModal();
  state.currentStepId = null;
  showIntroScreen();
}

function startDemoFromIntro() {
  hideIntroScreen();
  state.history = [];
  state.visitedStepIds = new Set();
  state.runStarted = false;
  state.runCompleted = false;
  setStep(getStartStepId(), { pushHistory: false });
}

function handleFrameClick(event) {
  if (state.introVisible) {
    return;
  }
  if (!getCurrentStep()?.hotspot) {
    return;
  }
  if (elements.hotspot.contains(event.target)) {
    return;
  }

  const frameRect = elements.frameHolder.getBoundingClientRect();
  const point = {
    x: event.clientX - frameRect.left,
    y: event.clientY - frameRect.top,
  };

  if (!isPointInsideHotspot(point, state.hotspotRect)) {
    nudgeTooltipHint();
  }
}

function onResize() {
  if (state.introVisible) {
    return;
  }
  const screen = getCurrentScreen();
  if (!screen) {
    return;
  }

  setFrameSize(screen);

  if (!elements.iframe.classList.contains("hidden")) {
    elements.iframe.style.transform = `scale(${state.frame.scale})`;
  }

  const step = getCurrentStep();
  if (!step) {
    return;
  }

  const hotspotRect = renderHotspot(step);
  if (!state.tooltipHidden) {
    setTooltipForStep(step, hotspotRect);
    updateArrowHint(step, hotspotRect);
  } else {
    elements.arrow.classList.add("hidden");
  }
}

function setupFrameResizeObserver() {
  if (typeof window.ResizeObserver === "undefined") {
    return;
  }
  if (frameResizeObserver) {
    frameResizeObserver.disconnect();
  }
  frameResizeObserver = new window.ResizeObserver(() => {
    onResize();
  });
  [elements.frameViewport, elements.frameLayout, elements.frameHolder, elements.chapterSidebar]
    .filter(Boolean)
    .forEach((node) => frameResizeObserver.observe(node));
}

function setupEventHandlers() {
  elements.hotspot?.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    onHotspotActivate();
  });

  elements.frameContent?.addEventListener("click", (event) => {
    handleFrameClick(event);
  });

  elements.prev?.addEventListener("click", () => goPrev());
  elements.next?.addEventListener("click", () => goNext());
  elements.tooltipPrev?.addEventListener("click", () => goPrev());
  elements.tooltipNext?.addEventListener("click", () => goNext());

  elements.restart?.addEventListener("click", () => restartRun());
  elements.restartEnd?.addEventListener("click", () => restartRun());
  elements.introStart?.addEventListener("click", () => startDemoFromIntro());
  elements.introSkip?.addEventListener("click", () => startDemoFromIntro());

  elements.openTab?.addEventListener("click", () => {
    window.open(window.location.href, "_blank", "noopener,noreferrer");
  });

  elements.toggleChapters?.addEventListener("click", () => {
    state.chaptersVisible = !state.chaptersVisible;
    elements.root.classList.toggle("chapters-collapsed", !state.chaptersVisible);
    renderChapterNav();
    onResize();
  });

  elements.fullscreen?.addEventListener("click", async () => {
    if (!document.fullscreenElement) {
      await elements.root.requestFullscreen?.();
      elements.fullscreen.textContent = "Exit Fullscreen";
    } else {
      await document.exitFullscreen?.();
      elements.fullscreen.textContent = "Fullscreen";
    }
  });

  elements.tooltipBody?.addEventListener("click", () => {
    const step = getCurrentStep();
    if (step?.advanceOnTooltipClick) {
      goNext();
    }
  });

  elements.feedbackRating?.addEventListener("click", (event) => {
    const button = event.target.closest(".feedback-score-btn");
    if (!button) {
      return;
    }
    const score = Number(button.dataset.score || 0);
    if (Number.isInteger(score) && score >= 1 && score <= 5) {
      setFeedbackScore(score);
      setFeedbackStatus("");
    }
  });

  elements.feedbackSubmit?.addEventListener("click", () => {
    submitFeedback();
  });

  elements.feedbackSkip?.addEventListener("click", () => {
    state.feedbackSkipped = true;
    closeFeedbackModal();
  });

  window.addEventListener("resize", () => onResize());

  document.addEventListener("keydown", (event) => {
    if (state.introVisible && (event.key === "ArrowRight" || event.key === "ArrowLeft")) {
      return;
    }
    if (event.key === "ArrowRight") {
      event.preventDefault();
      goNext();
      return;
    }
    if (event.key === "ArrowLeft") {
      event.preventDefault();
      goPrev();
      return;
    }
    if (event.key === "Escape") {
      if (document.fullscreenElement) {
        document.exitFullscreen?.();
        elements.fullscreen.textContent = "Fullscreen";
      }
      hideTooltip();
    }
  });
}

async function loadDemo() {
  const response = await fetch(`/api/demos/${state.slug}`);
  if (!response.ok) {
    throw new Error("Demo not found");
  }

  const demo = await response.json();
  state.demo = demo;
  buildMaps(demo);
}

function showLoadError() {
  hideIntroScreen();
  showLoading(false);
  hideAllMedia();
  elements.endScreen.classList.remove("hidden");
  elements.endScreen.innerHTML = "<h2>Demo not found</h2><p>Check the link and try again.</p>";
  elements.progress.textContent = "0 / 0";
}

export async function bootPlayerRuntime() {
  if (!validatePlayerDom()) {
    return;
  }
  setupEventHandlers();
  setupFrameResizeObserver();

  try {
    await loadDemo();
  } catch (_error) {
    showLoadError();
    return;
  }

  emitPlayerEvent("demo_view", {
    demoId: state.demo.id,
    slug: state.demo.slug,
    sessionId: getSessionId(),
  });

  renderBadge();
  renderChapterNav();

  if (!state.steps.length) {
    showEndScreen();
    return;
  }

  showIntroScreen();
}
