const demoTitleInput = document.getElementById("demo-title");
const demoSlugEl = document.getElementById("demo-slug");
const saveStatusEl = document.getElementById("save-status");
const saveButton = document.getElementById("save-demo");
const previewButton = document.getElementById("preview-demo");
const newDemoButton = document.getElementById("new-demo");
const exportJsonButton = document.getElementById("export-json");
const importJsonInput = document.getElementById("import-json");
const publishButton = document.getElementById("publish-demo");

const addStepButton = document.getElementById("add-step");
const addHotspotButton = document.getElementById("add-hotspot");
const addChapterButton = document.getElementById("add-chapter");
const stepEmptyState = document.getElementById("step-empty-state");
const chaptersList = document.getElementById("chapters-list");
const stepsList = document.getElementById("steps-list");
const dismissQuickstartButton = document.getElementById("dismiss-quickstart");
const quickstartPanel = document.getElementById("quickstart-panel");

const screenSelect = document.getElementById("screen-select");
const screenUpload = document.getElementById("screen-upload");
const removeScreenButton = document.getElementById("remove-screen");
const screenImage = document.getElementById("screen-image");
const screenVideo = document.getElementById("screen-video");
const imageStage = document.getElementById("image-stage");
const canvasEmpty = document.getElementById("canvas-empty");
const hotspotBox = document.getElementById("hotspot-box");
const drawRect = document.getElementById("draw-rect");
const builderHintLayer = document.getElementById("builder-hint-layer");
const builderCursor = document.getElementById("builder-cursor");
const builderArrow = document.getElementById("builder-arrow");

const stepTitleInput = document.getElementById("step-title");
const stepBodyInput = document.getElementById("step-body");
const nextStepSelect = document.getElementById("next-step");
const stepChapterSelect = document.getElementById("step-chapter");
const hotspotTypeSelect = document.getElementById("hotspot-type");
const hintTypeSelect = document.getElementById("hint-type");
const tooltipPositionSelect = document.getElementById("tooltip-position");
const focusModeToggle = document.getElementById("focus-mode");
const snapEdgesToggle = document.getElementById("snap-edges");
const testHotspotToggle = document.getElementById("test-hotspot");
const clearHotspotButton = document.getElementById("clear-hotspot");
const hotspotReadout = document.getElementById("hotspot-readout");
const stepTimeReadout = document.getElementById("step-time-readout");
const introEnabledInput = document.getElementById("intro-enabled");
const introTitleInput = document.getElementById("intro-title");
const introBodyInput = document.getElementById("intro-body");
const introStartLabelInput = document.getElementById("intro-start-label");
const introSkipLabelInput = document.getElementById("intro-skip-label");

const videoControls = document.getElementById("video-controls");
const videoPlayButton = document.getElementById("video-play");
const videoPauseButton = document.getElementById("video-pause");
const videoMarkerTrack = document.getElementById("video-marker-track");
const videoScrub = document.getElementById("video-scrub");
const videoTimeLabel = document.getElementById("video-time");
const setStepTimeButton = document.getElementById("set-step-time");
const addVideoMarkerButton = document.getElementById("add-video-marker");
const clearVideoMarkersButton = document.getElementById("clear-video-markers");
const recordButton = document.getElementById("record-screen");
const stopRecordButton = document.getElementById("stop-record");
const autoBuildButton = document.getElementById("auto-build-ai");
const exportCodexPackButton = document.getElementById("export-codex-pack");
const importCodexDraftInput = document.getElementById("import-codex-draft");

const toast = document.getElementById("toast");
const publishPanel = document.getElementById("publish-panel");
const shareUrlInput = document.getElementById("share-url");
const embedSnippetInput = document.getElementById("embed-snippet");
const startModal = document.getElementById("start-modal");
const startTitleInput = document.getElementById("start-title");
const createDemoButton = document.getElementById("create-demo");

const HOTSPOT_MIN_PX = 8;
const SNAP_THRESHOLD_PX = 8;
const UNDO_LIMIT = 80;

const state = {
  demo: null,
  currentStepId: null,
  dragStepId: null,
  autosaveTimer: null,
  dirty: false,
  isSaving: false,
  undoStack: [],
  redoStack: [],
  dragMode: null,
  dragStart: null,
  dragCurrent: null,
  editHandle: null,
  startHotspotPx: null,
};

let builderCursorCycle = 0;
let mediaRecorder = null;
let recordedChunks = [];

function selectedScreen() {
  if (!state.demo) {
    return null;
  }
  const selectedId = screenSelect.value || currentStep()?.screenId;
  return state.demo.screens.find((screen) => screen.id === selectedId) || null;
}

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function normalizeMarkerTimes(values, duration = null) {
  if (!Array.isArray(values)) {
    return [];
  }
  const max = Number.isFinite(duration) && duration > 0 ? duration : Number.POSITIVE_INFINITY;
  const seen = new Set();
  const normalized = [];
  for (const raw of values) {
    const value = Number(raw);
    if (!Number.isFinite(value) || value < 0) {
      continue;
    }
    const bounded = Math.min(value, max);
    const rounded = Number(bounded.toFixed(2));
    const key = rounded.toFixed(2);
    if (seen.has(key)) {
      continue;
    }
    seen.add(key);
    normalized.push(rounded);
  }
  normalized.sort((a, b) => a - b);
  return normalized;
}

function uuid() {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return "id-" + Math.random().toString(16).slice(2);
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove("hidden");
  setTimeout(() => toast.classList.add("hidden"), 2500);
}

function setSaveStatus(status) {
  saveStatusEl.classList.remove("saved", "saving", "unsaved");
  saveStatusEl.classList.add(status);
  if (status === "saving") {
    saveStatusEl.textContent = "Saving...";
    return;
  }
  if (status === "unsaved") {
    saveStatusEl.textContent = "Unsaved changes";
    return;
  }
  saveStatusEl.textContent = "Saved";
}

function safeLocalStorageSet(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch {
    // no-op
  }
}

function safeLocalStorageGet(key) {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function getDemoSlugFromQuery() {
  const params = new URLSearchParams(window.location.search);
  return (params.get("demo") || "").trim();
}

function syncBuilderQuery(slug) {
  const nextUrl = new URL(window.location.href);
  if (slug) {
    nextUrl.searchParams.set("demo", slug);
  } else {
    nextUrl.searchParams.delete("demo");
  }
  window.history.replaceState({}, "", `${nextUrl.pathname}${nextUrl.search}${nextUrl.hash}`);
}

function showModal(show) {
  if (show) {
    startModal.classList.remove("hidden");
  } else {
    startModal.classList.add("hidden");
  }
}

function resetDirty() {
  state.dirty = false;
  if (state.autosaveTimer) {
    window.clearTimeout(state.autosaveTimer);
    state.autosaveTimer = null;
  }
  setSaveStatus("saved");
}

function markDirty() {
  if (!state.demo) {
    return;
  }
  state.dirty = true;
  setSaveStatus("unsaved");
}

function pushUndoSnapshot() {
  if (!state.demo) {
    return;
  }
  state.undoStack.push({ demo: deepClone(state.demo), currentStepId: state.currentStepId });
  if (state.undoStack.length > UNDO_LIMIT) {
    state.undoStack.shift();
  }
  state.redoStack = [];
}

function applySnapshot(snapshot) {
  state.demo = deepClone(snapshot.demo);
  state.currentStepId = snapshot.currentStepId;
  ensureDemoDefaults(state.demo);
  renderAll();
  syncTopMeta();
  markDirty();
}

function undo() {
  if (!state.undoStack.length || !state.demo) {
    return;
  }
  state.redoStack.push({ demo: deepClone(state.demo), currentStepId: state.currentStepId });
  applySnapshot(state.undoStack.pop());
}

function redo() {
  if (!state.redoStack.length || !state.demo) {
    return;
  }
  state.undoStack.push({ demo: deepClone(state.demo), currentStepId: state.currentStepId });
  applySnapshot(state.redoStack.pop());
}

function syncTopMeta() {
  if (!state.demo) {
    demoSlugEl.textContent = "-";
    return;
  }
  demoTitleInput.value = state.demo.title || "";
  demoSlugEl.textContent = state.demo.slug || "-";
}

function normalizeStepOrder(steps) {
  steps.sort((a, b) => (a.order ?? 0) - (b.order ?? 0)).forEach((step, index) => {
    step.order = index;
  });
}

function normalizeScreenOrder(screens) {
  screens.sort((a, b) => (a.order ?? 0) - (b.order ?? 0)).forEach((screen, index) => {
    screen.order = index;
  });
}

function normalizeChapterOrder(chapters) {
  chapters.sort((a, b) => (a.order ?? 0) - (b.order ?? 0)).forEach((chapter, index) => {
    chapter.order = index;
  });
}

function sortSteps() {
  return [...state.demo.steps].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}

function sortChapters() {
  return [...state.demo.chapters].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}

function ensureDemoDefaults(demo) {
  demo.schemaVersion = Number.isInteger(demo.schemaVersion) ? demo.schemaVersion : 1;
  demo.status = demo.status || "draft";
  demo.ui = demo.ui || {};
  demo.ui.badge = demo.ui.badge || {};
  demo.ui.intro = demo.ui.intro || {};
  demo.ui.intro.enabled = demo.ui.intro.enabled !== false;
  demo.ui.intro.title = demo.ui.intro.title || "";
  demo.ui.intro.body = demo.ui.intro.body || "";
  demo.ui.intro.startLabel = demo.ui.intro.startLabel || "Start Interactive Demo";
  demo.ui.intro.skipLabel = demo.ui.intro.skipLabel || "Skip Intro";
  demo.chapters = Array.isArray(demo.chapters) ? demo.chapters : [];
  demo.screens = Array.isArray(demo.screens) ? demo.screens : [];
  demo.steps = Array.isArray(demo.steps) ? demo.steps : [];

  demo.chapters = demo.chapters.map((chapter, index) => ({
    id: chapter.id || uuid(),
    title: chapter.title || `Chapter ${index + 1}`,
    order: Number.isInteger(chapter.order) ? chapter.order : index,
  }));
  normalizeChapterOrder(demo.chapters);

  demo.screens = demo.screens.map((screen, index) => ({
    id: screen.id || uuid(),
    mediaType: screen.mediaType || "image",
    mediaUrl: screen.mediaUrl || screen.imageUrl || "",
    imageUrl: screen.imageUrl || screen.mediaUrl || "",
    naturalWidth: screen.naturalWidth ?? null,
    naturalHeight: screen.naturalHeight ?? null,
    duration: screen.duration ?? null,
    markers: normalizeMarkerTimes(screen.markers, screen.duration ?? null),
    order: Number.isInteger(screen.order) ? screen.order : index,
  }));
  normalizeScreenOrder(demo.screens);

  demo.steps = demo.steps.map((step, index) => ({
    id: step.id || uuid(),
    screenId: step.screenId || null,
    title: step.title || `Step ${index + 1}`,
    body: step.body || "",
    hotspot: step.hotspot || null,
    hotspotType: step.hotspotType || "click",
    hintType: step.hintType || "click",
    tooltipPosition: step.tooltipPosition || "auto",
    timeSec: step.timeSec ?? null,
    chapterId: step.chapterId || null,
    nextStepId: step.nextStepId || null,
    order: Number.isInteger(step.order) ? step.order : index,
  }));
  normalizeStepOrder(demo.steps);
}

function ensureStepSelection() {
  if (!state.demo.steps.length) {
    state.currentStepId = null;
    return;
  }
  if (!state.currentStepId || !state.demo.steps.find((step) => step.id === state.currentStepId)) {
    state.currentStepId = sortSteps()[0].id;
  }
}

function currentStep() {
  if (!state.demo || !state.currentStepId) {
    return null;
  }
  return state.demo.steps.find((step) => step.id === state.currentStepId) || null;
}

function formatApiErrors(detail) {
  if (Array.isArray(detail)) {
    return detail.map((item) => item.msg || item.message || JSON.stringify(item)).join(" | ");
  }
  if (typeof detail === "string") {
    return detail;
  }
  return "Request failed.";
}

async function createDemo(title) {
  const response = await fetch("/api/demos", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title }),
  });
  if (!response.ok) {
    showToast("Failed to create demo.");
    return null;
  }
  return response.json();
}

async function createNewDemoInstance() {
  if (state.dirty) {
    const shouldContinue = window.confirm("Create a new demo? Unsaved changes in the current demo will be lost.");
    if (!shouldContinue) {
      return;
    }
  }
  const title = `Untitled Demo ${new Date().toLocaleString()}`;
  const demo = await createDemo(title);
  if (!demo) {
    return;
  }
  setDemo(demo);
  showModal(false);
  showToast("New demo ready.");
}

async function loadDemo(slug) {
  const response = await fetch(`/api/demos/${slug}`);
  if (!response.ok) {
    return null;
  }
  return response.json();
}

async function saveDemo({ silent = false } = {}) {
  if (!state.demo || state.isSaving) {
    return;
  }
  if (!state.demo.startStepId && state.demo.steps.length > 0) {
    state.demo.startStepId = sortSteps()[0].id;
  }
  state.demo.title = demoTitleInput.value.trim() || "Untitled Demo";
  state.isSaving = true;
  setSaveStatus("saving");
  try {
    const response = await fetch(`/api/demos/${state.demo.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(state.demo),
    });
    const payload = await response.json();
    if (!response.ok) {
      showToast(formatApiErrors(payload.detail));
      setSaveStatus("unsaved");
      return;
    }
    state.demo = payload;
    ensureDemoDefaults(state.demo);
    syncTopMeta();
    renderAll();
    resetDirty();
    if (!silent) {
      showToast("Demo saved.");
    }
  } catch {
    setSaveStatus("unsaved");
    showToast("Save failed.");
  } finally {
    state.isSaving = false;
  }
}

async function exportDemoJson() {
  if (!state.demo) {
    return;
  }
  const response = await fetch(`/api/demos/${state.demo.id}/export`);
  if (!response.ok) {
    showToast("Export failed.");
    return;
  }
  const payload = await response.json();
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${payload.slug || "demo"}.json`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

async function importDemoJson(file) {
  if (!file) {
    return;
  }
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    const response = await fetch("/api/demos/import", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    const payload = await response.json();
    if (!response.ok) {
      showToast(formatApiErrors(payload.detail));
      return;
    }
    setDemo(payload);
    showToast("Demo imported.");
  } catch {
    showToast("Invalid JSON import.");
  } finally {
    importJsonInput.value = "";
  }
}

function setDemo(demo) {
  ensureDemoDefaults(demo);
  state.demo = demo;
  state.currentStepId = null;
  state.undoStack = [];
  state.redoStack = [];
  safeLocalStorageSet("ig_demo_slug", demo.slug);
  syncBuilderQuery(demo.slug);
  ensureStepSelection();
  syncTopMeta();
  renderAll();
  resetDirty();
  publishPanel.classList.add("hidden");
}

function renderAll() {
  renderChapters();
  renderScreens();
  renderSteps();
  renderStepDetails();
  renderIntroSettings();
  renderEmptyStates();
}

function renderIntroSettings() {
  if (!state.demo) {
    introEnabledInput.checked = true;
    introTitleInput.value = "";
    introBodyInput.value = "";
    introStartLabelInput.value = "Start Interactive Demo";
    introSkipLabelInput.value = "Skip Intro";
    return;
  }
  const intro = state.demo.ui?.intro || {};
  introEnabledInput.checked = intro.enabled !== false;
  introTitleInput.value = intro.title || "";
  introBodyInput.value = intro.body || "";
  introStartLabelInput.value = intro.startLabel || "Start Interactive Demo";
  introSkipLabelInput.value = intro.skipLabel || "Skip Intro";
}

function renderEmptyStates() {
  const hasScreens = !!state.demo?.screens?.length;
  canvasEmpty.textContent = hasScreens ? "Select a screen to continue." : "Upload image/video to start";
  stepEmptyState.classList.toggle("hidden", !!state.demo?.steps?.length);
}

function renderScreens() {
  screenSelect.innerHTML = "";
  if (!state.demo || !state.demo.screens.length) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "No media yet";
    screenSelect.appendChild(option);
    screenSelect.disabled = true;
    removeScreenButton.disabled = true;
    return;
  }
  screenSelect.disabled = false;
  removeScreenButton.disabled = false;
  state.demo.screens
    .slice()
    .sort((a, b) => a.order - b.order)
    .forEach((screen) => {
      const option = document.createElement("option");
      option.value = screen.id;
      option.textContent = `${screen.mediaType === "video" ? "Video" : "Screen"} ${screen.order + 1}`;
      screenSelect.appendChild(option);
    });
}

function renderChapters() {
  chaptersList.innerHTML = "";
  if (!state.demo) {
    return;
  }
  sortChapters().forEach((chapter) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "chapter-chip";
    button.textContent = chapter.title;
    button.addEventListener("click", () => {
      const firstStep = sortSteps().find((step) => step.chapterId === chapter.id);
      if (firstStep) {
        selectStep(firstStep.id);
      }
    });
    chaptersList.appendChild(button);
  });
  renderChapterOptions();
}

function renderChapterOptions() {
  stepChapterSelect.innerHTML = "";
  const none = document.createElement("option");
  none.value = "";
  none.textContent = "No chapter";
  stepChapterSelect.appendChild(none);
  sortChapters().forEach((chapter) => {
    const option = document.createElement("option");
    option.value = chapter.id;
    option.textContent = chapter.title;
    stepChapterSelect.appendChild(option);
  });
}

function renderNextStepOptions() {
  nextStepSelect.innerHTML = "";
  const endOption = document.createElement("option");
  endOption.value = "";
  endOption.textContent = "End demo";
  nextStepSelect.appendChild(endOption);
  sortSteps().forEach((step) => {
    const option = document.createElement("option");
    option.value = step.id;
    option.textContent = step.title || "Untitled step";
    nextStepSelect.appendChild(option);
  });
}

function renderSteps() {
  stepsList.innerHTML = "";
  if (!state.demo) {
    return;
  }
  const ordered = sortSteps();
  normalizeStepOrder(ordered);
  state.demo.steps = ordered;

  const chapterMap = new Map(sortChapters().map((chapter) => [chapter.id, chapter.title]));
  const grouped = [];
  const buckets = new Map();
  sortChapters().forEach((chapter) => {
    const bucket = [];
    buckets.set(chapter.id, bucket);
    grouped.push({ title: chapter.title, steps: bucket });
  });
  const unassigned = [];
  ordered.forEach((step) => {
    if (step.chapterId && buckets.has(step.chapterId)) {
      buckets.get(step.chapterId).push(step);
    } else {
      unassigned.push(step);
    }
  });
  if (unassigned.length) {
    grouped.push({ title: "Unassigned", steps: unassigned });
  }

  grouped.forEach((group) => {
    if (!group.steps.length) {
      return;
    }
    const heading = document.createElement("div");
    heading.className = "step-group-title";
    heading.textContent = group.title;
    stepsList.appendChild(heading);

    group.steps.forEach((step) => {
      const item = document.createElement("button");
      item.type = "button";
      item.className = "step-item" + (step.id === state.currentStepId ? " active" : "");
      item.draggable = true;
      item.dataset.stepId = step.id;
      item.addEventListener("dragstart", () => {
        state.dragStepId = step.id;
        item.classList.add("dragging");
      });
      item.addEventListener("dragend", () => {
        state.dragStepId = null;
        item.classList.remove("dragging");
      });
      item.addEventListener("dragover", (event) => {
        event.preventDefault();
        item.classList.add("drag-over");
      });
      item.addEventListener("dragleave", () => item.classList.remove("drag-over"));
      item.addEventListener("drop", (event) => {
        event.preventDefault();
        item.classList.remove("drag-over");
        if (!state.dragStepId || state.dragStepId === step.id) {
          return;
        }
        pushUndoSnapshot();
        moveStepBefore(state.dragStepId, step.id);
      });

      const head = document.createElement("div");
      head.className = "step-head";
      const title = document.createElement("div");
      title.textContent = step.title || "Untitled";
      head.appendChild(title);
      const actions = document.createElement("div");
      actions.className = "step-actions";
      const copyButton = document.createElement("button");
      copyButton.type = "button";
      copyButton.className = "step-action-btn";
      copyButton.textContent = "Copy";
      copyButton.addEventListener("click", (event) => {
        event.stopPropagation();
        pushUndoSnapshot();
        duplicateStep(step.id);
      });
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "step-action-btn danger";
      deleteButton.textContent = "Delete";
      deleteButton.addEventListener("click", (event) => {
        event.stopPropagation();
        pushUndoSnapshot();
        deleteStep(step.id);
      });
      actions.append(copyButton, deleteButton);
      head.appendChild(actions);

      const screen = state.demo.screens.find((itemScreen) => itemScreen.id === step.screenId);
      const meta = document.createElement("span");
      const screenText = screen ? `${screen.mediaType === "video" ? "Video" : "Screen"} ${(screen.order ?? 0) + 1}` : "No media";
      const chapterText = step.chapterId ? chapterMap.get(step.chapterId) || "Missing chapter" : "No chapter";
      meta.textContent = `${screenText} | ${chapterText}`;

      item.append(head, meta);
      item.addEventListener("click", () => selectStep(step.id));
      stepsList.appendChild(item);
    });
  });
  renderNextStepOptions();
  renderVideoMarkers();
}

function selectStep(stepId) {
  state.currentStepId = stepId;
  renderSteps();
  renderStepDetails();
}

function getMediaElement() {
  return screenVideo.classList.contains("hidden") ? screenImage : screenVideo;
}

function getMediaRectInLayer() {
  const mediaEl = getMediaElement();
  const mediaRect = mediaEl.getBoundingClientRect();
  const layerRect = builderHintLayer.getBoundingClientRect();
  return {
    x: mediaRect.left - layerRect.left,
    y: mediaRect.top - layerRect.top,
    width: mediaRect.width,
    height: mediaRect.height,
  };
}

function hotspotToPixels(hotspot) {
  if (!hotspot) {
    return null;
  }
  const media = getMediaRectInLayer();
  if (!media.width || !media.height) {
    return null;
  }
  return {
    x: media.x + hotspot.xPct * media.width,
    y: media.y + hotspot.yPct * media.height,
    w: hotspot.wPct * media.width,
    h: hotspot.hPct * media.height,
  };
}

function drawHotspotRect(rectPx, hotspotType) {
  hotspotBox.style.display = "block";
  hotspotBox.style.left = `${rectPx.x}px`;
  hotspotBox.style.top = `${rectPx.y}px`;
  hotspotBox.style.width = `${rectPx.w}px`;
  hotspotBox.style.height = `${rectPx.h}px`;
  hotspotBox.classList.toggle("highlight", hotspotType === "highlight");
  hotspotBox.classList.add("editable");
}

function updateHotspotBox(hotspot) {
  if (!hotspot) {
    hotspotBox.style.display = "none";
    hotspotBox.classList.remove("highlight");
    hotspotReadout.textContent = "Draw a hotspot on the media.";
    updateHintPreview(null, "none");
    return;
  }
  const rectPx = hotspotToPixels(hotspot);
  if (!rectPx) {
    return;
  }
  const step = currentStep();
  drawHotspotRect(rectPx, step?.hotspotType || "click");
  hotspotReadout.textContent = `Hotspot: ${hotspot.xPct.toFixed(3)}, ${hotspot.yPct.toFixed(3)}, ${hotspot.wPct.toFixed(3)}, ${hotspot.hPct.toFixed(3)}`;
  updateHintPreview(rectPx, step?.hintType || "click");
}

function renderStepDetails() {
  const step = currentStep();
  renderChapterOptions();
  if (!step) {
    stepTitleInput.value = "";
    stepBodyInput.value = "";
    nextStepSelect.value = "";
    stepChapterSelect.value = "";
    hotspotTypeSelect.value = "click";
    hintTypeSelect.value = "click";
    tooltipPositionSelect.value = "auto";
    updateHotspotBox(null);
    stepTimeReadout.classList.add("hidden");
    renderVideoMarkers();
    return;
  }
  stepTitleInput.value = step.title || "";
  stepBodyInput.value = step.body || "";
  nextStepSelect.value = step.nextStepId || "";
  stepChapterSelect.value = step.chapterId || "";
  hotspotTypeSelect.value = step.hotspotType || "click";
  hintTypeSelect.value = step.hintType || "click";
  tooltipPositionSelect.value = step.tooltipPosition || "auto";
  if (step.screenId) {
    screenSelect.value = step.screenId;
    loadScreen(step.screenId);
  } else if (state.demo.screens.length) {
    step.screenId = state.demo.screens[0].id;
    screenSelect.value = step.screenId;
    loadScreen(step.screenId);
    markDirty();
  }
  updateHotspotBox(step.hotspot);
  updateStepTimeReadout(step);
  renderVideoMarkers();
}

function loadScreen(screenId) {
  const screen = state.demo.screens.find((item) => item.id === screenId);
  if (!screen) {
    imageStage.classList.add("hidden");
    canvasEmpty.classList.remove("hidden");
    return;
  }
  canvasEmpty.classList.add("hidden");
  imageStage.classList.remove("hidden");
  const mediaUrl = screen.mediaUrl || screen.imageUrl;
  if (screen.mediaType === "video") {
    screenImage.classList.add("hidden");
    screenVideo.classList.remove("hidden");
    videoControls.classList.remove("hidden");
    stepTimeReadout.classList.remove("hidden");
    screenVideo.src = mediaUrl;
    screenVideo.pause();
    const step = currentStep();
    if (step && typeof step.timeSec === "number") {
      screenVideo.currentTime = step.timeSec;
    }
    renderVideoMarkers();
  } else {
    screenVideo.classList.add("hidden");
    screenImage.classList.remove("hidden");
    videoControls.classList.add("hidden");
    stepTimeReadout.classList.add("hidden");
    screenVideo.removeAttribute("src");
    const syncImageMetadata = () => {
      screen.naturalWidth = screenImage.naturalWidth || screen.naturalWidth || null;
      screen.naturalHeight = screenImage.naturalHeight || screen.naturalHeight || null;
      updateHotspotBox(currentStep()?.hotspot || null);
      markDirty();
    };
    screenImage.onload = syncImageMetadata;
    screenImage.src = mediaUrl;
    if (screenImage.complete && screenImage.naturalWidth) {
      syncImageMetadata();
    }
    renderVideoMarkers();
  }
}

function updateStepTimeReadout(step) {
  if (!step || screenVideo.classList.contains("hidden")) {
    stepTimeReadout.classList.add("hidden");
    stepTimeReadout.textContent = "Video time: --";
    return;
  }
  stepTimeReadout.classList.remove("hidden");
  const value = typeof step.timeSec === "number" ? step.timeSec.toFixed(2) : "--";
  stepTimeReadout.textContent = `Video time: ${value}s`;
}

function getSelectedVideoScreen() {
  const screen = selectedScreen();
  if (!screen || screen.mediaType !== "video") {
    return null;
  }
  const duration = Number(screen.duration ?? screenVideo.duration ?? 0);
  screen.markers = normalizeMarkerTimes(screen.markers, duration);
  return screen;
}

function getStepMarkersForScreen(screenId) {
  if (!state.demo || !screenId) {
    return [];
  }
  const stepMap = new Map();
  sortSteps().forEach((step) => {
    if (step.screenId !== screenId || typeof step.timeSec !== "number" || !Number.isFinite(step.timeSec)) {
      return;
    }
    const rounded = Number(step.timeSec.toFixed(2));
    const key = rounded.toFixed(2);
    if (!stepMap.has(key)) {
      stepMap.set(key, { timeSec: rounded, stepId: step.id, title: step.title || "Step" });
    }
  });
  return [...stepMap.values()].sort((a, b) => a.timeSec - b.timeSec);
}

function jumpToVideoTime(timeSec) {
  if (screenVideo.classList.contains("hidden")) {
    return;
  }
  const duration = Number(screenVideo.duration || 0);
  const bounded =
    Number.isFinite(duration) && duration > 0 ? clamp(Number(timeSec) || 0, 0, duration) : Math.max(Number(timeSec) || 0, 0);
  screenVideo.currentTime = bounded;
  videoScrub.value = bounded.toFixed(2);
  videoTimeLabel.textContent = `${bounded.toFixed(2)}s`;
}

function renderVideoMarkers() {
  if (!videoMarkerTrack) {
    return;
  }
  videoMarkerTrack.innerHTML = "";
  const screen = getSelectedVideoScreen();
  const duration = Number(screenVideo.duration || screen?.duration || 0);
  if (!screen || screenVideo.classList.contains("hidden") || !Number.isFinite(duration) || duration <= 0) {
    videoMarkerTrack.classList.add("empty");
    clearVideoMarkersButton.disabled = true;
    return;
  }

  const currentStepId = currentStep()?.id || "";
  const markerByTime = new Map();
  const stepMarkers = getStepMarkersForScreen(screen.id);
  stepMarkers.forEach((item) => {
    const key = item.timeSec.toFixed(2);
    markerByTime.set(key, { timeSec: item.timeSec, stepId: item.stepId, title: item.title, type: "step" });
  });
  (screen.markers || []).forEach((timeValue) => {
    const normalized = Number(timeValue.toFixed(2));
    const key = normalized.toFixed(2);
    const existing = markerByTime.get(key);
    if (existing) {
      existing.type = "both";
    } else {
      markerByTime.set(key, { timeSec: normalized, stepId: "", title: "Key marker", type: "key" });
    }
  });

  const markers = [...markerByTime.values()].sort((a, b) => a.timeSec - b.timeSec);
  videoMarkerTrack.classList.toggle("empty", !markers.length);
  clearVideoMarkersButton.disabled = !screen.markers?.length;

  markers.forEach((marker) => {
    const markerButton = document.createElement("button");
    markerButton.type = "button";
    markerButton.className = "video-marker";
    if (marker.type === "key" || marker.type === "both") {
      markerButton.classList.add("key");
    }
    if (marker.type === "step" || marker.type === "both") {
      markerButton.classList.add("step");
    }
    if (marker.stepId && marker.stepId === currentStepId) {
      markerButton.classList.add("active");
    }
    const position = clamp((marker.timeSec / duration) * 100, 0, 100);
    markerButton.style.left = `${position}%`;
    markerButton.title = `${marker.timeSec.toFixed(2)}s${marker.stepId ? ` - ${marker.title}` : " - Key marker"}`;
    markerButton.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      jumpToVideoTime(marker.timeSec);
      if (marker.stepId) {
        selectStep(marker.stepId);
      }
    });
    videoMarkerTrack.appendChild(markerButton);
  });
}

function addVideoMarkerAtCurrentTime() {
  const screen = getSelectedVideoScreen();
  if (!screen || screenVideo.classList.contains("hidden")) {
    showToast("Select a video screen first.");
    return;
  }
  const duration = Number(screenVideo.duration || screen.duration || 0);
  const markerTime = Number((screenVideo.currentTime || 0).toFixed(2));
  pushUndoSnapshot();
  screen.markers = normalizeMarkerTimes([...(screen.markers || []), markerTime], duration);
  renderVideoMarkers();
  markDirty();
  showToast(`Marker added at ${markerTime.toFixed(2)}s`);
}

function clearVideoMarkers() {
  const screen = getSelectedVideoScreen();
  if (!screen || !screen.markers?.length) {
    return;
  }
  if (!window.confirm("Clear all key markers for this video screen?")) {
    return;
  }
  pushUndoSnapshot();
  screen.markers = [];
  renderVideoMarkers();
  markDirty();
  showToast("Video markers cleared.");
}

function updateHintPreview(hotspotPx, hintType) {
  builderCursorCycle += 1;
  const cycleId = builderCursorCycle;
  if (!hotspotPx || hintType === "none") {
    builderCursor.classList.add("hidden");
    builderArrow.classList.add("hidden");
    return;
  }
  const layerWidth = builderHintLayer.offsetWidth;
  const layerHeight = builderHintLayer.offsetHeight;
  if (!layerWidth || !layerHeight) {
    return;
  }
  if (hintType === "arrow") {
    builderCursor.classList.add("hidden");
    const targetX = clamp(hotspotPx.x + hotspotPx.w * 0.5, 16, layerWidth - 16);
    const targetY = clamp(hotspotPx.y + hotspotPx.h * 0.5, 16, layerHeight - 16);
    const startX = clamp(targetX - 140, 16, layerWidth - 16);
    const startY = clamp(targetY - 90, 16, layerHeight - 16);
    const dx = targetX - startX;
    const dy = targetY - startY;
    const length = Math.max(Math.hypot(dx, dy), 40);
    const angle = Math.atan2(dy, dx);
    builderArrow.style.width = `${length}px`;
    builderArrow.style.left = `${startX}px`;
    builderArrow.style.top = `${startY}px`;
    builderArrow.style.transform = `translateY(-50%) rotate(${angle}rad)`;
    builderArrow.classList.remove("hidden");
    return;
  }

  builderArrow.classList.add("hidden");
  const startX = clamp(hotspotPx.x - 20, 16, layerWidth - 16);
  const startY = clamp(hotspotPx.y - 20, 16, layerHeight - 16);
  const targetX = clamp(hotspotPx.x + hotspotPx.w * 0.7, 16, layerWidth - 16);
  const targetY = clamp(hotspotPx.y + hotspotPx.h * 0.7, 16, layerHeight - 16);
  builderCursor.style.transition = "none";
  builderCursor.style.left = `${startX}px`;
  builderCursor.style.top = `${startY}px`;
  builderCursor.classList.remove("hidden", "cursor-click");
  requestAnimationFrame(() => {
    if (cycleId !== builderCursorCycle) {
      return;
    }
    builderCursor.style.transition = "left 0.6s ease, top 0.6s ease";
    builderCursor.style.left = `${targetX}px`;
    builderCursor.style.top = `${targetY}px`;
  });
  setTimeout(() => {
    if (cycleId !== builderCursorCycle) {
      return;
    }
    builderCursor.classList.remove("cursor-click");
    void builderCursor.offsetWidth;
    builderCursor.classList.add("cursor-click");
  }, 650);
  setTimeout(() => {
    if (cycleId === builderCursorCycle) {
      updateHintPreview(hotspotPx, hintType);
    }
  }, 2300);
}

function updateStepFromInputs() {
  const step = currentStep();
  if (!step) {
    return;
  }
  step.title = stepTitleInput.value.trim();
  step.body = stepBodyInput.value.trim();
  step.nextStepId = nextStepSelect.value || null;
  step.chapterId = stepChapterSelect.value || null;
  step.hotspotType = hotspotTypeSelect.value || "click";
  step.hintType = hintTypeSelect.value || "click";
  step.tooltipPosition = tooltipPositionSelect.value || "auto";
  renderSteps();
  updateHotspotBox(step.hotspot);
  updateStepTimeReadout(step);
  markDirty();
}

function updateIntroFromInputs() {
  if (!state.demo) {
    return;
  }
  state.demo.ui = state.demo.ui || {};
  state.demo.ui.intro = state.demo.ui.intro || {};
  state.demo.ui.intro.enabled = introEnabledInput.checked;
  state.demo.ui.intro.title = introTitleInput.value.trim();
  state.demo.ui.intro.body = introBodyInput.value.trim();
  state.demo.ui.intro.startLabel = introStartLabelInput.value.trim() || "Start Interactive Demo";
  state.demo.ui.intro.skipLabel = introSkipLabelInput.value.trim() || "Skip Intro";
  markDirty();
}

async function handleUpload(files) {
  if (!state.demo) {
    return;
  }
  pushUndoSnapshot();
  for (const file of files) {
    const body = new FormData();
    body.append("file", file);
    const response = await fetch("/api/uploads", { method: "POST", body });
    const payload = await response.json();
    if (!response.ok) {
      showToast(formatApiErrors(payload.detail));
      continue;
    }
    const mediaType = payload.mediaType || (file.type.startsWith("video/") ? "video" : "image");
    const mediaUrl = payload.mediaUrl || payload.imageUrl;
    state.demo.screens.push({
      id: uuid(),
      mediaType,
      mediaUrl,
      imageUrl: mediaUrl,
      naturalWidth: payload.naturalWidth || null,
      naturalHeight: payload.naturalHeight || null,
      duration: null,
      markers: [],
      order: state.demo.screens.length,
    });
  }
  normalizeScreenOrder(state.demo.screens);
  renderAll();
  markDirty();
}

function dataUrlToBase64(dataUrl) {
  const marker = "base64,";
  const index = dataUrl.indexOf(marker);
  if (index < 0) {
    return "";
  }
  return dataUrl.slice(index + marker.length);
}

function seekVideoTo(videoEl, timeSec) {
  return new Promise((resolve) => {
    const onSeeked = () => {
      videoEl.removeEventListener("seeked", onSeeked);
      resolve();
    };
    videoEl.addEventListener("seeked", onSeeked, { once: true });
    videoEl.currentTime = Math.max(0, timeSec);
    setTimeout(() => {
      videoEl.removeEventListener("seeked", onSeeked);
      resolve();
    }, 800);
  });
}

function ensureVideoReady(videoEl) {
  return new Promise((resolve) => {
    if (videoEl.readyState >= 1 && videoEl.duration > 0) {
      resolve();
      return;
    }
    const onLoaded = () => {
      videoEl.removeEventListener("loadedmetadata", onLoaded);
      resolve();
    };
    videoEl.addEventListener("loadedmetadata", onLoaded, { once: true });
  });
}

async function captureStoryboardFrames(videoEl, maxFrames = 7, preferredTimes = []) {
  await ensureVideoReady(videoEl);
  const duration = Number(videoEl.duration || 0);
  if (!Number.isFinite(duration) || duration <= 0.25) {
    return [];
  }

  const frames = [];
  const width = videoEl.videoWidth || 1280;
  const height = videoEl.videoHeight || 720;
  const scale = Math.min(1, 960 / width);
  const outWidth = Math.max(Math.round(width * scale), 320);
  const outHeight = Math.max(Math.round(height * scale), 180);
  const canvas = document.createElement("canvas");
  canvas.width = outWidth;
  canvas.height = outHeight;
  const ctx = canvas.getContext("2d");

  const normalizedPreferred = normalizeMarkerTimes(preferredTimes, duration);
  const count = Math.max(4, Math.min(12, Math.max(maxFrames, normalizedPreferred.length)));
  const timeline = [...normalizedPreferred];
  for (let index = 0; timeline.length < count && index < count * 3; index += 1) {
    const ratio = count === 1 ? 0.5 : 0.04 + (index / (count - 1)) * 0.9;
    const timeSec = Number((duration * ratio).toFixed(2));
    timeline.push(timeSec);
  }

  const selectedTimeline = normalizeMarkerTimes(timeline, duration).slice(0, count);
  for (const timeSec of selectedTimeline) {
    await seekVideoTo(videoEl, timeSec);
    ctx.drawImage(videoEl, 0, 0, outWidth, outHeight);
    const dataUrl = canvas.toDataURL("image/jpeg", 0.7);
    frames.push({ timeSec, imageBase64: dataUrlToBase64(dataUrl) });
  }
  return frames;
}

function downloadJsonFile(data, filename) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

async function prepareAutoBuildFrames(maxFrames = 7) {
  if (state.dirty) {
    await saveDemo({ silent: true });
    if (state.dirty) {
      showToast("Please save demo changes before Auto Build.");
      return null;
    }
  }

  const screen = selectedScreen();
  if (!screen || screen.mediaType !== "video") {
    showToast("Select a video screen first.");
    return null;
  }

  if (screenVideo.classList.contains("hidden")) {
    loadScreen(screen.id);
  }
  const keyMarkers = normalizeMarkerTimes(screen.markers, screen.duration ?? screenVideo.duration ?? null);
  const frames = await captureStoryboardFrames(screenVideo, maxFrames, keyMarkers);
  if (!frames.length) {
    showToast("Could not extract frames from video.");
    return null;
  }
  return { screen, frames, keyMarkers };
}

function buildCodexPack(screen, frames, keyMarkers = []) {
  const stepMarkers = getStepMarkersForScreen(screen.id).map((item) => ({
    timeSec: item.timeSec,
    stepId: item.stepId,
    title: item.title,
  }));
  return {
    workflow: "codex-auto-build",
    version: 1,
    generatedAt: new Date().toISOString(),
    demo: {
      id: state.demo.id,
      slug: state.demo.slug,
      title: state.demo.title,
    },
    screen: {
      id: screen.id,
      mediaType: screen.mediaType,
      mediaUrl: screen.mediaUrl || "",
      duration: screen.duration ?? null,
      keyMarkers,
      stepMarkers,
    },
    instructions: {
      summary:
        "Use this storyboard to generate a guided product demo draft. Return JSON only with chapters and steps.",
      outputSchema: {
        screenId: "use the same screen.id",
        overwrite: true,
        chapters: [{ title: "chapter title" }],
        steps: [
          {
            title: "clear action title",
            body: "specific instruction tied to UI seen in frame",
            timeSec: 12.34,
            chapterTitle: "must match one chapter title",
            hintType: "click | arrow | none",
            tooltipPosition: "auto | top | right | bottom | left",
            hotspot: { xPct: 0.1, yPct: 0.1, wPct: 0.2, hPct: 0.15 },
          },
        ],
      },
      constraints: [
        "Create 5-8 steps.",
        "Avoid generic wording.",
        "Use varied hotspots based on visible UI targets.",
        "All hotspot values must stay within 0..1.",
      ],
    },
    frames,
  };
}

async function exportForCodex() {
  if (!state.demo) {
    showToast("Create a demo first.");
    return;
  }

  exportCodexPackButton.disabled = true;
  exportCodexPackButton.textContent = "Exporting...";
  try {
    const prepared = await prepareAutoBuildFrames(7);
    if (!prepared) {
      return;
    }
    const payload = buildCodexPack(prepared.screen, prepared.frames, prepared.keyMarkers || []);
    const filename = `${state.demo.slug || "demo"}-codex-storyboard.json`;
    downloadJsonFile(payload, filename);
    showToast("Codex storyboard exported.");
  } catch {
    showToast("Export for Codex failed.");
  } finally {
    exportCodexPackButton.disabled = false;
    exportCodexPackButton.textContent = "Export For Codex";
  }
}

function normalizeCodexDraftPayload(raw) {
  if (!raw || typeof raw !== "object") {
    return null;
  }
  const source = raw.draft || raw.draftRequest || raw;
  if (!source || typeof source !== "object") {
    return null;
  }
  const screenId = (source.screenId || selectedScreen()?.id || "").trim();
  const steps = Array.isArray(source.steps) ? source.steps : [];
  const chapters = Array.isArray(source.chapters) ? source.chapters : [];
  if (!screenId || !steps.length) {
    return null;
  }
  return {
    screenId,
    overwrite: source.overwrite !== false,
    chapters,
    steps,
  };
}

async function importCodexDraft(file) {
  if (!state.demo) {
    showToast("Create a demo first.");
    return;
  }
  if (!file) {
    return;
  }

  if (state.dirty) {
    await saveDemo({ silent: true });
    if (state.dirty) {
      showToast("Please save demo changes before importing draft.");
      return;
    }
  }

  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    const draft = normalizeCodexDraftPayload(parsed);
    if (!draft) {
      showToast("Invalid Codex draft file.");
      return;
    }
    const response = await fetch(`/api/demos/${state.demo.id}/auto-build/from-draft`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(draft),
    });
    const payload = await response.json();
    if (!response.ok) {
      showToast(formatApiErrors(payload.detail || "Draft import failed."));
      return;
    }
    setDemo(payload);
    showToast("Codex draft imported.");
  } catch {
    showToast("Codex draft import failed.");
  } finally {
    importCodexDraftInput.value = "";
  }
}

async function autoBuildFromVideo() {
  if (!state.demo) {
    showToast("Create a demo first.");
    return;
  }

  const shouldOverwrite =
    !state.demo.steps.length ||
    window.confirm("Replace current steps with AI-generated draft steps from this recording?");
  if (!shouldOverwrite) {
    return;
  }

  autoBuildButton.disabled = true;
  autoBuildButton.textContent = "Generating...";
  try {
    const prepared = await prepareAutoBuildFrames(7);
    if (!prepared) {
      return;
    }
    const { screen, frames } = prepared;
    const response = await fetch(`/api/demos/${state.demo.id}/auto-build`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        screenId: screen.id,
        overwrite: true,
        frames,
      }),
    });
    const payload = await response.json();
    if (!response.ok) {
      showToast(formatApiErrors(payload.detail || payload.message || "Auto build failed."));
      return;
    }
    const autoBuildMode = response.headers.get("x-autobuild-mode") || "ai";
    const autoBuildReason = response.headers.get("x-autobuild-reason") || "";
    setDemo(payload);
    if (autoBuildMode === "fallback") {
      showToast(
        autoBuildReason
          ? `AI unavailable, fallback draft created: ${autoBuildReason}`
          : "AI unavailable, fallback draft created."
      );
    } else {
      showToast("AI-generated demo draft ready.");
    }
  } catch {
    showToast("Auto build failed.");
  } finally {
    autoBuildButton.disabled = false;
    autoBuildButton.textContent = "Auto Build (AI)";
  }
}

function moveStepBefore(sourceStepId, targetStepId) {
  const ordered = sortSteps();
  const sourceIndex = ordered.findIndex((step) => step.id === sourceStepId);
  const targetIndex = ordered.findIndex((step) => step.id === targetStepId);
  if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) {
    return;
  }
  const [source] = ordered.splice(sourceIndex, 1);
  const insertIndex = targetIndex > sourceIndex ? targetIndex - 1 : targetIndex;
  ordered.splice(insertIndex, 0, source);
  normalizeStepOrder(ordered);
  state.demo.steps = ordered;
  renderAll();
  markDirty();
}

function duplicateStep(stepId) {
  const ordered = sortSteps();
  const index = ordered.findIndex((step) => step.id === stepId);
  if (index < 0) {
    return;
  }
  const clone = deepClone(ordered[index]);
  clone.id = uuid();
  clone.title = `${clone.title || "Step"} (copy)`;
  ordered.splice(index + 1, 0, clone);
  normalizeStepOrder(ordered);
  state.demo.steps = ordered;
  state.currentStepId = clone.id;
  renderAll();
  markDirty();
}

function deleteStep(stepId) {
  state.demo.steps = state.demo.steps.filter((step) => step.id !== stepId);
  state.demo.steps.forEach((step) => {
    if (step.nextStepId === stepId) {
      step.nextStepId = null;
    }
  });
  normalizeStepOrder(state.demo.steps);
  if (!state.demo.steps.length) {
    state.currentStepId = null;
    state.demo.startStepId = null;
  } else {
    state.currentStepId = state.demo.steps[0].id;
    if (state.demo.startStepId === stepId) {
      state.demo.startStepId = state.currentStepId;
    }
  }
  renderAll();
  markDirty();
}

function addStep() {
  pushUndoSnapshot();
  const newStep = {
    id: uuid(),
    screenId: state.demo.screens[0]?.id || null,
    title: `Step ${state.demo.steps.length + 1}`,
    body: "",
    hotspot: null,
    hotspotType: "click",
    hintType: "click",
    tooltipPosition: "auto",
    timeSec: !screenVideo.classList.contains("hidden") ? screenVideo.currentTime : null,
    chapterId: state.demo.chapters[0]?.id || null,
    nextStepId: null,
    order: state.demo.steps.length,
  };
  const ordered = sortSteps();
  if (ordered.length) {
    const last = ordered[ordered.length - 1];
    if (!last.nextStepId) {
      last.nextStepId = newStep.id;
    }
  }
  state.demo.steps.push(newStep);
  normalizeStepOrder(state.demo.steps);
  state.currentStepId = newStep.id;
  renderAll();
  markDirty();
}

function addHotspotSameFrame() {
  pushUndoSnapshot();
  const baseStep = currentStep();
  const newStep = {
    id: uuid(),
    screenId: baseStep?.screenId || state.demo.screens[0]?.id || null,
    title: `Step ${state.demo.steps.length + 1}`,
    body: "",
    hotspot: null,
    hotspotType: baseStep?.hotspotType || "click",
    hintType: baseStep?.hintType || "click",
    tooltipPosition: baseStep?.tooltipPosition || "auto",
    timeSec:
      typeof baseStep?.timeSec === "number"
        ? baseStep.timeSec
        : !screenVideo.classList.contains("hidden")
          ? screenVideo.currentTime
          : null,
    chapterId: baseStep?.chapterId || null,
    nextStepId: null,
    order: state.demo.steps.length,
  };
  if (baseStep && !baseStep.nextStepId) {
    baseStep.nextStepId = newStep.id;
  }
  state.demo.steps.push(newStep);
  normalizeStepOrder(state.demo.steps);
  state.currentStepId = newStep.id;
  renderAll();
  markDirty();
}

function addChapter() {
  pushUndoSnapshot();
  const chapter = {
    id: uuid(),
    title: `Chapter ${state.demo.chapters.length + 1}`,
    order: state.demo.chapters.length,
  };
  state.demo.chapters.push(chapter);
  normalizeChapterOrder(state.demo.chapters);
  const step = currentStep();
  if (step && !step.chapterId) {
    step.chapterId = chapter.id;
  }
  renderAll();
  markDirty();
}

function removeSelectedScreen() {
  if (!screenSelect.value) {
    return;
  }
  pushUndoSnapshot();
  const removedId = screenSelect.value;
  state.demo.screens = state.demo.screens.filter((screen) => screen.id !== removedId);
  normalizeScreenOrder(state.demo.screens);
  state.demo.steps.forEach((step) => {
    if (step.screenId === removedId) {
      step.screenId = state.demo.screens[0]?.id || null;
      step.hotspot = null;
    }
  });
  renderAll();
  markDirty();
}

function pointerToLayer(event) {
  const layerRect = builderHintLayer.getBoundingClientRect();
  return { x: event.clientX - layerRect.left, y: event.clientY - layerRect.top };
}

function applySnap(value, maxValue) {
  if (!snapEdgesToggle.checked) {
    return value;
  }
  if (value < SNAP_THRESHOLD_PX) {
    return 0;
  }
  if (maxValue - value < SNAP_THRESHOLD_PX) {
    return maxValue;
  }
  return value;
}

function setHotspotFromRect(rectPx, shouldMarkDirty = true) {
  const step = currentStep();
  if (!step) {
    return;
  }
  const media = getMediaRectInLayer();
  const maxX = media.x + media.width;
  const maxY = media.y + media.height;
  rectPx.x = clamp(rectPx.x, media.x, maxX - HOTSPOT_MIN_PX);
  rectPx.y = clamp(rectPx.y, media.y, maxY - HOTSPOT_MIN_PX);
  rectPx.w = clamp(rectPx.w, HOTSPOT_MIN_PX, maxX - rectPx.x);
  rectPx.h = clamp(rectPx.h, HOTSPOT_MIN_PX, maxY - rectPx.y);
  rectPx.x = applySnap(rectPx.x, maxX);
  rectPx.y = applySnap(rectPx.y, maxY);
  const right = applySnap(rectPx.x + rectPx.w, maxX);
  const bottom = applySnap(rectPx.y + rectPx.h, maxY);
  rectPx.w = clamp(right - rectPx.x, HOTSPOT_MIN_PX, maxX - rectPx.x);
  rectPx.h = clamp(bottom - rectPx.y, HOTSPOT_MIN_PX, maxY - rectPx.y);

  step.hotspot = {
    xPct: (rectPx.x - media.x) / media.width,
    yPct: (rectPx.y - media.y) / media.height,
    wPct: rectPx.w / media.width,
    hPct: rectPx.h / media.height,
  };
  updateHotspotBox(step.hotspot);
  if (shouldMarkDirty) {
    markDirty();
  }
}

function hotspotRectFromStep() {
  const step = currentStep();
  if (!step?.hotspot) {
    return null;
  }
  return hotspotToPixels(step.hotspot);
}

function testHotspot(point) {
  const step = currentStep();
  if (!step?.hotspot) {
    showToast("No hotspot configured.");
    return;
  }
  const media = getMediaRectInLayer();
  const xPct = (point.x - media.x) / media.width;
  const yPct = (point.y - media.y) / media.height;
  const inside =
    xPct >= step.hotspot.xPct &&
    yPct >= step.hotspot.yPct &&
    xPct <= step.hotspot.xPct + step.hotspot.wPct &&
    yPct <= step.hotspot.yPct + step.hotspot.hPct;
  showToast(inside ? "Hotspot hit: would advance." : "Hotspot miss.");
}

imageStage.addEventListener("pointerdown", (event) => {
  const step = currentStep();
  if (!step || !state.demo?.screens?.length) {
    return;
  }
  const point = pointerToLayer(event);
  if (testHotspotToggle.checked) {
    testHotspot(point);
    return;
  }

  const handle = event.target?.dataset?.handle;
  if (handle && step.hotspot) {
    pushUndoSnapshot();
    state.dragMode = "resize";
    state.dragStart = point;
    state.editHandle = handle;
    state.startHotspotPx = hotspotRectFromStep();
    imageStage.setPointerCapture(event.pointerId);
    return;
  }

  if (event.target === hotspotBox && step.hotspot) {
    pushUndoSnapshot();
    state.dragMode = "move";
    state.dragStart = point;
    state.startHotspotPx = hotspotRectFromStep();
    imageStage.setPointerCapture(event.pointerId);
    return;
  }

  if (event.target.closest(".hotspot-box")) {
    return;
  }

  pushUndoSnapshot();
  state.dragMode = "draw";
  state.dragStart = point;
  state.dragCurrent = point;
  drawRect.style.display = "block";
  imageStage.setPointerCapture(event.pointerId);
});

imageStage.addEventListener("pointermove", (event) => {
  if (!state.dragMode) {
    return;
  }
  const point = pointerToLayer(event);
  if (state.dragMode === "draw") {
    state.dragCurrent = point;
    const x = Math.min(state.dragStart.x, point.x);
    const y = Math.min(state.dragStart.y, point.y);
    const w = Math.abs(point.x - state.dragStart.x);
    const h = Math.abs(point.y - state.dragStart.y);
    drawRect.style.left = `${x}px`;
    drawRect.style.top = `${y}px`;
    drawRect.style.width = `${w}px`;
    drawRect.style.height = `${h}px`;
    return;
  }

  if (!state.startHotspotPx) {
    return;
  }
  const dx = point.x - state.dragStart.x;
  const dy = point.y - state.dragStart.y;
  const base = state.startHotspotPx;
  const rect = { x: base.x, y: base.y, w: base.w, h: base.h };
  if (state.dragMode === "move") {
    rect.x += dx;
    rect.y += dy;
  } else if (state.dragMode === "resize") {
    if (state.editHandle.includes("w")) {
      rect.x += dx;
      rect.w -= dx;
    }
    if (state.editHandle.includes("e")) {
      rect.w += dx;
    }
    if (state.editHandle.includes("n")) {
      rect.y += dy;
      rect.h -= dy;
    }
    if (state.editHandle.includes("s")) {
      rect.h += dy;
    }
  }
  setHotspotFromRect(rect, false);
});

imageStage.addEventListener("pointerup", (event) => {
  if (!state.dragMode) {
    return;
  }
  if (state.dragMode === "draw") {
    const point = pointerToLayer(event);
    const x = Math.min(state.dragStart.x, point.x);
    const y = Math.min(state.dragStart.y, point.y);
    const w = Math.abs(point.x - state.dragStart.x);
    const h = Math.abs(point.y - state.dragStart.y);
    drawRect.style.display = "none";
    if (w < HOTSPOT_MIN_PX || h < HOTSPOT_MIN_PX) {
      showToast("Hotspot too small.");
    } else {
      setHotspotFromRect({ x, y, w, h }, true);
    }
  } else {
    markDirty();
  }

  state.dragMode = null;
  state.dragStart = null;
  state.dragCurrent = null;
  state.startHotspotPx = null;
  state.editHandle = null;
});

function nudgeHotspot(dx, dy) {
  const rect = hotspotRectFromStep();
  if (!rect) {
    return;
  }
  pushUndoSnapshot();
  setHotspotFromRect({ x: rect.x + dx, y: rect.y + dy, w: rect.w, h: rect.h }, true);
}

function handleKeyboardShortcuts(event) {
  const isMeta = event.ctrlKey || event.metaKey;
  const tag = (event.target?.tagName || "").toUpperCase();
  const isTyping = tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT";
  if (isMeta && event.key.toLowerCase() === "s") {
    event.preventDefault();
    saveDemo();
    return;
  }
  if (isMeta && event.key.toLowerCase() === "z" && !event.shiftKey) {
    event.preventDefault();
    undo();
    return;
  }
  if (isMeta && event.key.toLowerCase() === "z" && event.shiftKey) {
    event.preventDefault();
    redo();
    return;
  }
  if (isTyping) {
    return;
  }
  const amount = event.shiftKey ? 10 : 1;
  if (event.key === "ArrowUp") {
    event.preventDefault();
    nudgeHotspot(0, -amount);
  } else if (event.key === "ArrowDown") {
    event.preventDefault();
    nudgeHotspot(0, amount);
  } else if (event.key === "ArrowLeft") {
    event.preventDefault();
    nudgeHotspot(-amount, 0);
  } else if (event.key === "ArrowRight") {
    event.preventDefault();
    nudgeHotspot(amount, 0);
  }
}

async function publishDemo() {
  if (!state.demo) {
    return;
  }
  state.demo.status = "published";
  markDirty();
  await saveDemo({ silent: true });
  const url = `${window.location.origin}/demo/${state.demo.slug}`;
  shareUrlInput.value = url;
  embedSnippetInput.value = `<iframe src="${url}" style="width:100%;height:600px;border:0;border-radius:12px;overflow:hidden;" loading="lazy"></iframe>`;
  publishPanel.classList.remove("hidden");
}

function setQuickstartVisibility() {
  const dismissed = safeLocalStorageGet("ig_quickstart_dismissed") === "1";
  quickstartPanel.classList.toggle("hidden", dismissed);
}

screenImage.setAttribute("draggable", "false");
screenVideo.setAttribute("draggable", "false");
screenImage.addEventListener("dragstart", (event) => event.preventDefault());
screenVideo.addEventListener("dragstart", (event) => event.preventDefault());

screenVideo.addEventListener("timeupdate", () => {
  if (!videoScrub.matches(":active")) {
    videoScrub.value = screenVideo.currentTime.toFixed(2);
  }
  videoTimeLabel.textContent = `${screenVideo.currentTime.toFixed(2)}s`;
});

screenVideo.addEventListener("loadedmetadata", () => {
  const screen = state.demo?.screens?.find((item) => item.id === screenSelect.value);
  if (screen) {
    screen.naturalWidth = screenVideo.videoWidth || null;
    screen.naturalHeight = screenVideo.videoHeight || null;
    screen.duration = screenVideo.duration || null;
  }
  videoScrub.max = screenVideo.duration ? screenVideo.duration.toFixed(2) : "0";
  const step = currentStep();
  if (step && typeof step.timeSec === "number") {
    screenVideo.currentTime = step.timeSec;
  }
  updateHotspotBox(step?.hotspot || null);
  updateStepTimeReadout(step);
  renderVideoMarkers();
});

stepTitleInput.addEventListener("input", updateStepFromInputs);
stepBodyInput.addEventListener("input", updateStepFromInputs);
nextStepSelect.addEventListener("change", updateStepFromInputs);
stepChapterSelect.addEventListener("change", updateStepFromInputs);
hotspotTypeSelect.addEventListener("change", updateStepFromInputs);
hintTypeSelect.addEventListener("change", updateStepFromInputs);
tooltipPositionSelect.addEventListener("change", updateStepFromInputs);
introEnabledInput.addEventListener("change", updateIntroFromInputs);
introTitleInput.addEventListener("input", updateIntroFromInputs);
introBodyInput.addEventListener("input", updateIntroFromInputs);
introStartLabelInput.addEventListener("input", updateIntroFromInputs);
introSkipLabelInput.addEventListener("input", updateIntroFromInputs);

focusModeToggle.addEventListener("change", () => imageStage.classList.toggle("focus-mode", focusModeToggle.checked));
testHotspotToggle.addEventListener("change", () =>
  showToast(testHotspotToggle.checked ? "Test hotspot mode enabled." : "Test hotspot mode disabled.")
);

screenSelect.addEventListener("change", () => {
  const step = currentStep();
  if (!step) {
    return;
  }
  step.screenId = screenSelect.value || null;
  step.hotspot = null;
  loadScreen(step.screenId);
  renderSteps();
  updateHotspotBox(null);
  markDirty();
});

clearHotspotButton.addEventListener("click", () => {
  const step = currentStep();
  if (!step) {
    return;
  }
  pushUndoSnapshot();
  step.hotspot = null;
  updateHotspotBox(null);
  markDirty();
});

screenUpload.addEventListener("change", async (event) => {
  const files = Array.from(event.target.files || []);
  await handleUpload(files);
  screenUpload.value = "";
});

videoPlayButton.addEventListener("click", () => !screenVideo.classList.contains("hidden") && screenVideo.play());
videoPauseButton.addEventListener("click", () => !screenVideo.classList.contains("hidden") && screenVideo.pause());
videoScrub.addEventListener("input", () => {
  if (!screenVideo.classList.contains("hidden")) {
    screenVideo.currentTime = parseFloat(videoScrub.value || "0");
  }
});
addVideoMarkerButton.addEventListener("click", addVideoMarkerAtCurrentTime);
clearVideoMarkersButton.addEventListener("click", clearVideoMarkers);
setStepTimeButton.addEventListener("click", () => {
  const step = currentStep();
  if (!step || screenVideo.classList.contains("hidden")) {
    return;
  }
  pushUndoSnapshot();
  step.timeSec = screenVideo.currentTime;
  updateStepTimeReadout(step);
  renderVideoMarkers();
  markDirty();
});

recordButton.addEventListener("click", async () => {
  if (!state.demo) {
    showToast("Create a demo first.");
    return;
  }
  if (!navigator.mediaDevices?.getDisplayMedia || typeof MediaRecorder === "undefined") {
    showToast("Screen recording not supported.");
    return;
  }
  const stream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
  recordedChunks = [];
  const options = MediaRecorder.isTypeSupported("video/webm") ? { mimeType: "video/webm" } : undefined;
  mediaRecorder = new MediaRecorder(stream, options);
  mediaRecorder.ondataavailable = (event) => event.data?.size && recordedChunks.push(event.data);
  mediaRecorder.onstop = async () => {
    stream.getTracks().forEach((track) => track.stop());
    const blob = new Blob(recordedChunks, { type: "video/webm" });
    const file = new File([blob], `recording-${Date.now()}.webm`, { type: "video/webm" });
    await handleUpload([file]);
    recordButton.classList.remove("hidden");
    stopRecordButton.classList.add("hidden");
  };
  mediaRecorder.start();
  recordButton.classList.add("hidden");
  stopRecordButton.classList.remove("hidden");
});

stopRecordButton.addEventListener("click", () => mediaRecorder && mediaRecorder.state !== "inactive" && mediaRecorder.stop());
autoBuildButton.addEventListener("click", autoBuildFromVideo);
exportCodexPackButton.addEventListener("click", exportForCodex);
importCodexDraftInput.addEventListener("change", async (event) => {
  const file = Array.from(event.target.files || [])[0];
  await importCodexDraft(file);
});

addStepButton.addEventListener("click", addStep);
addHotspotButton.addEventListener("click", addHotspotSameFrame);
addChapterButton.addEventListener("click", addChapter);
removeScreenButton.addEventListener("click", removeSelectedScreen);

saveButton.addEventListener("click", () => saveDemo());
previewButton.addEventListener("click", async () => {
  if (!state.demo) {
    return;
  }
  if (state.dirty) {
    await saveDemo({ silent: true });
  }
  window.open(`/demo/${state.demo.slug}`, "_blank");
});
newDemoButton.addEventListener("click", createNewDemoInstance);
publishButton.addEventListener("click", publishDemo);
exportJsonButton.addEventListener("click", exportDemoJson);
importJsonInput.addEventListener("change", async (event) => {
  const file = Array.from(event.target.files || [])[0];
  await importDemoJson(file);
});

demoTitleInput.addEventListener("input", () => {
  if (!state.demo) {
    return;
  }
  state.demo.title = demoTitleInput.value.trim();
  markDirty();
});

dismissQuickstartButton.addEventListener("click", () => {
  safeLocalStorageSet("ig_quickstart_dismissed", "1");
  setQuickstartVisibility();
});

createDemoButton.addEventListener("click", async () => {
  const title = startTitleInput.value.trim() || "Untitled Demo";
  const demo = await createDemo(title);
  if (!demo) {
    return;
  }
  showModal(false);
  setDemo(demo);
});

window.addEventListener("keydown", handleKeyboardShortcuts);
window.addEventListener("resize", () => updateHotspotBox(currentStep()?.hotspot || null));

async function boot() {
  setQuickstartVisibility();
  imageStage.classList.toggle("focus-mode", focusModeToggle.checked);
  if (!navigator.mediaDevices?.getDisplayMedia || typeof MediaRecorder === "undefined") {
    recordButton.classList.add("hidden");
    stopRecordButton.classList.add("hidden");
  }
  const requestedSlug = getDemoSlugFromQuery();
  if (requestedSlug) {
    const demo = await loadDemo(requestedSlug);
    if (demo) {
      showModal(false);
      setDemo(demo);
      return;
    }
    showToast(`Could not load demo "${requestedSlug}".`);
  }
  const savedSlug = safeLocalStorageGet("ig_demo_slug");
  if (savedSlug) {
    const demo = await loadDemo(savedSlug);
    if (demo) {
      showModal(false);
      setDemo(demo);
      return;
    }
  }
  showModal(true);
}

boot();
